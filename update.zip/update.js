// update.js
'use strict';

const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const path = require('path');
const fs = require('fs');
const https = require('https');
const localVersion = require('./version.js'); // offline sumber versi (opsional)
const INSTALL_DIR = 'C:\\Program Files\\VNC Launcher';
let updateWin = null;

// ====== SETUP: versi & URL online ======
const REMOTE_VERSION_URL = 'https://github.com/DROISD123/vnc/blob/main/version.json';
const REMOTE_ZIP_URL     = 'https://github.com/DROISD123/vnc/blob/main/update.zip';

// ====== REGISTER IPC ======
function registerUpdateIPC() {
  ipcMain.on('open-update', openUpdateWindow);
  ipcMain.handle('update:check', onCheckUpdate);
  ipcMain.handle('update:download', onDownloadUpdate);
  ipcMain.handle('update:apply', onApplyUpdate);
}

function openUpdateWindow() {
  if (updateWin && !updateWin.isDestroyed()) return updateWin.focus();
  const parent = BrowserWindow.getFocusedWindow();
  updateWin = new BrowserWindow({
    width: 720, height: 460, title: 'Update',
    modal: !!parent, parent,
    autoHideMenuBar: true,
    webPreferences: { contextIsolation: true, preload: path.join(__dirname, 'preload.js') }
  });
  updateWin.on('closed', () => (updateWin = null));
  updateWin.loadFile('update.html').catch(() =>
    dialog.showErrorBox('Update', 'File update.html tidak ditemukan.')
  );
}

// ====== CHECK (online + fallback offline) ======
async function onCheckUpdate() {
  const current = String(localVersion?.version || '0.0.0'); // dari version.js (optional)
  try {
    const url = toRawUrl(REMOTE_VERSION_URL);
    const remote = await fetchJson(url, 8000);
    const remoteVersion = String(remote?.version || '').trim() || '0.0.0';
    // jika version.json tidak menyediakan zipUrl, pakai default yang kamu kasih
    remote.zipUrl = remote?.zipUrl || toRawUrl(REMOTE_ZIP_URL);

    const diff = compareSemver(remoteVersion, current);
    return { ok: true, current, remoteVersion, hasUpdate: diff > 0, remote };
  } catch (e) {
    log(`update:check fallback offline: ${e?.message || e}`);
    // fallback: tidak ada update (offline)
    return {
      ok: true,
      current,
      remoteVersion: current,
      hasUpdate: false,
      remote: { zipUrl: toRawUrl(REMOTE_ZIP_URL) },
      offline: true
    };
  }
}

// ====== DOWNLOAD (pakai argumen atau default) ======
async function onDownloadUpdate(_e, { url } = {}) {
  try {
    const finalUrl = toRawUrl(url || REMOTE_ZIP_URL);
    const targetDir = path.join(app.getPath('userData'), 'updates');
    fs.mkdirSync(targetDir, { recursive: true });
    const filePath = path.join(targetDir, `update-${Date.now()}.zip`);

    await downloadFile(finalUrl, filePath, (p) => {
      if (updateWin && !updateWin.isDestroyed()) {
        updateWin.webContents.send('update:progress', p); // 0..1
      }
    });

    return { ok: true, filePath };
  } catch (e) {
    log(`download error: ${e?.message || e}`);
    return { ok: false, error: e?.message || String(e) };
  }
}

// ====== APPLY (ekstrak ZIP & relaunch) ======
// ====== APPLY (langsung ekstrak & relaunch) ======
async function onApplyUpdate(_e, { zipPath }) {
  try {
    if (!zipPath || !fs.existsSync(zipPath)) {
      return { ok: false, error: 'File ZIP tidak ditemukan/ belum diunduh' };
    }

    const targetDir = INSTALL_DIR; // langsung ke folder instalasi tetap
    fs.mkdirSync(targetDir, { recursive: true });

    await extractZip(zipPath, targetDir); // LANGSUNG EKSTRAK (tanpa elevasi)

    dialog.showMessageBoxSync({
      type: 'info',
      title: 'Update',
      message: 'Update selesai diekstrak. Aplikasi akan di-restart.'
    });

    app.relaunch();
    app.exit(0);
    return { ok: true };
  } catch (e) {
    log(`apply error: ${e?.message || e}`);
    return { ok: false, error: e?.message || String(e) };
  }
}


// ====== UTIL ======
function toRawUrl(u) {
  if (!u) return u;
  // dukung:
  // 1) https://github.com/{owner}/{repo}/blob/{branch}/path/file
  // 2) https://raw.githubusercontent.com/{owner}/{repo}/{branch}/path/file
  if (/^https:\/\/github\.com\/.+\/blob\//i.test(u)) {
    return u.replace(
      /^https:\/\/github\.com\/([^/]+)\/([^/]+)\/blob\/([^/]+)\/(.+)$/i,
      'https://raw.githubusercontent.com/$1/$2/$3/$4'
    );
  }
  return u;
}

function fetchJson(url, timeoutMs = 10000) {
  return new Promise((resolve, reject) => {
    const req = https.get(url + '?nocache=' + Date.now(), {
      headers: { 'User-Agent': 'Electron-Updater', 'Accept': 'application/json' }
    }, (res) => {
      if (res.statusCode && res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        return resolve(fetchJson(res.headers.location, timeoutMs));
      }
      if (res.statusCode !== 200) return reject(new Error(`HTTP ${res.statusCode}`));
      let data = '';
      res.setEncoding('utf8');
      res.on('data', (c) => (data += c));
      res.on('end', () => { try { resolve(JSON.parse(data)); } catch (e) { reject(e); } });
    });
    req.on('error', reject);
    req.setTimeout(timeoutMs, () => { req.destroy(new Error('Request timeout')); });
  });
}

function downloadFile(url, dest, onProgress) {
  return new Promise((resolve, reject) => {
    const file = fs.createWriteStream(dest);
    https.get(url, (res) => {
      if (res.statusCode && res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        // follow redirect untuk file
        return downloadFile(res.headers.location, dest, onProgress).then(resolve, reject);
      }
      if (res.statusCode !== 200) return reject(new Error(`HTTP ${res.statusCode}`));
      const total = parseInt(res.headers['content-length'] || '0', 10);
      let loaded = 0;
      res.on('data', (chunk) => {
        loaded += chunk.length;
        if (typeof onProgress === 'function' && total) onProgress(loaded / total);
      });
      res.pipe(file);
      file.on('finish', () => file.close(() => resolve(dest)));
    }).on('error', (err) => {
      try { fs.unlinkSync(dest); } catch {}
      reject(err);
    });
  });
}

function extractZip(zipPath, targetDir) {
  return new Promise((resolve, reject) => {
    if (process.platform === 'win32') {
      const { spawn } = require('child_process');
      const ps = spawn('powershell.exe', [
        '-NoProfile', '-Command',
        `Try { Expand-Archive -Path "${zipPath}" -DestinationPath "${targetDir}" -Force; Exit 0 } Catch { Write-Error $_; Exit 1 }`
      ], { windowsHide: true });
      ps.on('exit', (code) => code === 0 ? resolve() : reject(new Error('Expand-Archive failed')));
      ps.on('error', reject);
    } else {
      const { spawn } = require('child_process');
      const cmd = fs.existsSync('/usr/bin/unzip') ? 'unzip' : 'tar';
      const args = (cmd === 'unzip')
        ? ['-o', zipPath, '-d', targetDir]
        : ['-xf', zipPath, '-C', targetDir];
      const p = spawn(cmd, args);
      p.on('exit', (code) => code === 0 ? resolve() : reject(new Error(`${cmd} failed`)));
      p.on('error', reject);
    }
  });
}

function compareSemver(a, b) {
  const pa = String(a).split('.').map(n => parseInt(n) || 0);
  const pb = String(b).split('.').map(n => parseInt(n) || 0);
  for (let i = 0; i < 3; i++) {
    if ((pa[i]||0) > (pb[i]||0)) return 1;
    if ((pa[i]||0) < (pb[i]||0)) return -1;
  }
  return 0;
}

function log(msg) {
  if (updateWin && !updateWin.isDestroyed()) {
    try { updateWin.webContents.send('update:log', String(msg)); } catch {}
  }
  console.log('[update]', msg);
}

module.exports = { registerUpdateIPC, openUpdateWindow };
