// ===== Utilities =====
    const $ = (id) => document.getElementById(id);
    const logBox = $('log'), dot = $('dot'), lbl = $('lblStatus');
    let ALL_PROFILES = []; // cache profil dari online/cache

    function logLine(s){
      const ts = new Date().toLocaleTimeString();
      logBox.textContent += `[${ts}] ${s}\n`;
      logBox.scrollTop = logBox.scrollHeight;
    }
    function setStatus(state){
      dot.classList.remove('connected','disconnected','busy');
      if (state === 'busy') { dot.classList.add('busy'); lbl.textContent='Working...'; return; }
      if (state === 'connected'){ dot.classList.add('connected'); lbl.textContent='Connected'; }
      else { dot.classList.add('disconnected'); lbl.textContent='Disconnected'; }
    }
    function fileDownload(filename, text){
      const blob = new Blob([text], {type:'text/plain;charset=utf-8'});
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a'); a.href = url; a.download = filename; a.click();
      URL.revokeObjectURL(url);
    }

    // ===== PSK toggle (khusus L2TP) =====
    function togglePSK(){
      const show = $('proto').value === 'l2tp';
      $('pskWrap').style.display = show ? '' : 'none';
    }

    // ===== Profiles =====
    function populateProfiles(list){
      const sel = $('selProfile');
      const filter = $('txtFilter').value.trim().toLowerCase();
      sel.innerHTML = '';
      const filtered = list.filter(it => {
        const label = (it.name || `${it.server || ''} ${it.proto || ''}`).toLowerCase();
        return !filter || label.includes(filter);
      });
      if (!filtered.length){
        const o = document.createElement('option'); o.value=''; o.textContent='Tidak ada profil dari ' + ($('chipSource').textContent.split('(')[0].trim()); o.disabled = true; sel.appendChild(o);
      } else {
        if (!sel.firstChild){ const ph = document.createElement('option'); ph.value=''; ph.textContent='— pilih profil —'; ph.disabled=true; ph.selected=true; sel.appendChild(ph); }
        for (const it of filtered){ const o = document.createElement('option');
          o.value = JSON.stringify(it);
          o.textContent = it.name || `${it.server || ''} ${it.proto || ''}`.trim();
          sel.appendChild(o);
        }
      }
    }
    function applyProfile(p){
      if (!p) return;
      $('name').value   = p.name || (p.server ? `VPN-${p.server}` : 'VPN');
      $('server').value = p.server || '';
      $('proto').value  = (p.proto === 'l2tp' ? 'l2tp' : 'pptp');
      $('user').value   = p.username || '';
      $('pass').value   = p.password || '';
      $('psk').value    = p.psk || '';
      $('notes').value  = p.notes || '';
      togglePSK();
    }
    async function loadProfiles(){
      try{
        const res = await window.electronAPI?.vpnLoadList?.();
        if (!res?.ok) throw new Error(res?.error || 'Gagal memuat vpn.json');
        ALL_PROFILES = Array.isArray(res.items) ? res.items : [];
        $('chipSource').textContent = (res.source || (res.cached ? 'Cache' : 'Online')) + ' (' + (Array.isArray(res.items)?res.items.length:0) + ')';
        populateProfiles(ALL_PROFILES);
        console.debug('[VPN UI] profiles:', ALL_PROFILES.length);
        if (ALL_PROFILES.length) applyProfile(ALL_PROFILES[0]);
        logLine(`Loaded ${ALL_PROFILES.length} profile(s)` + (res.cached ? ' (cache)' : ''));
      }catch(e){
        $('chipSource').textContent = 'Offline';
        populateProfiles([]);
        logLine('Load profiles error: ' + (e?.message || e));
      }
    }

    // ===== Connect / Disconnect =====
    async function onConnect(){
      try{
        setStatus('busy');
        const cfg = {
          name: $('name').value.trim(),
          server: $('server').value.trim(),
          proto: $('proto').value,
          username: $('user').value.trim(),
          password: $('pass').value,
          psk: $('psk').value,
          notes: $('notes').value.trim()
        };
        $('btnConnect').disabled = true;
        logLine('Connecting...');
        const res = await window.electronAPI?.vpnConnect?.(cfg);
        if (res?.ok){ setStatus('connected'); logLine(res.message || 'Connected'); }
        else { setStatus('disconnected'); logLine('Error: ' + (res?.error || 'unknown')); }
      }catch(e){
        setStatus('disconnected'); logLine('Error: ' + (e?.message || e));
      }finally{
        $('btnConnect').disabled = false;
      }
    }
    async function onDisconnect(){
      try{
        setStatus('busy'); logLine('Disconnecting...');
        const res = await window.electronAPI?.vpnDisconnect?.();
        if (res?.ok){ setStatus('disconnected'); logLine('Disconnected'); }
        else { setStatus('disconnected'); logLine('Error: ' + (res?.error || 'unknown')); }
      }catch(e){
        setStatus('disconnected'); logLine('Error: ' + (e?.message || e));
      }
    }

    // ===== Titlebar buttons =====
    $('btnClose')?.addEventListener('click', () => window.electronAPI?.closeVpnWindow?.());
    $('btnMin')?.addEventListener('click', () => window.electronAPI?.minimizeVpnWindow?.());

    async function refreshPinState(){
      try{
        const on = await window.electronAPI?.getVpnAlwaysOnTop?.();
        $('btnPin')?.classList.toggle('pin-on', !!on);
        $('btnPin').title = on ? 'Always on top: ON' : 'Always on top: OFF';
      }catch{}
    }
    $('btnPin')?.addEventListener('click', async () => {
      try{
        const on = await window.electronAPI?.toggleVpnAlwaysOnTop?.();
        $('btnPin')?.classList.toggle('pin-on', !!on);
        $('btnPin').title = on ? 'Always on top: ON' : 'Always on top: OFF';
      }catch{}
    });

    // ===== Listeners & bindings =====
    window.electronAPI?.onVpnLog?.((m)=> logLine(m));
    $('proto').addEventListener('change', togglePSK);
    $('selProfile').addEventListener('change', (e)=>{ try{ const p = JSON.parse(e.target.value); applyProfile(p); }catch{} });
    $('txtFilter').addEventListener('input', ()=> populateProfiles(ALL_PROFILES));
    $('btnReload').addEventListener('click', loadProfiles);
    $('btnConnect').addEventListener('click', onConnect);
    $('btnDisconnect').addEventListener('click', onDisconnect);

    // Log tools
    $('btnCopyLog').addEventListener('click', async ()=>{
      try{
        await navigator.clipboard.writeText(logBox.textContent || '');
        alert('Log disalin.');
      }catch{ alert('Gagal menyalin log.'); }
    });
    $('btnClearLog').addEventListener('click', ()=> logBox.textContent='');
    $('btnSaveLog').addEventListener('click', ()=> fileDownload('vpn-log.txt', logBox.textContent || ''));

    // Shortcuts
    window.addEventListener('keydown', (e)=>{
      if (e.key === 'Escape') window.electronAPI?.closeVpnWindow?.();
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'enter') onConnect();
    });

    // Init
    refreshPinState();
    loadProfiles();
    togglePSK();
    setStatus('disconnected');