module.exports = {
  version: '1.0.2',      // ← ganti setiap rilis offline
  build: '2025-08-15',   // opsional
  notes: 'Initial offline build' // opsional
};