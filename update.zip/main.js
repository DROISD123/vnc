// main.js — FULL (no .env; GitHub token sesi/in-memory; commit auth.json via API)

'use strict';

const { app, BrowserWindow, ipcMain, shell, dialog } = require('electron');

const vpn = require('./vpn'); // VPN module
const path = require('path');
const fs = require('fs');
const xlsx = require('xlsx');
const { exec, spawn } = require('child_process');
const ftp = require('basic-ftp');
const https = require('https');
const { registerUpdateIPC, openUpdateWindow } = require('./update');
const localVersion = require('./version.js');
// === KONFIG ===
const CONFIG_PATH = path.join(__dirname, 'config.json');
const config = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));
const DATA_PATH = path.join(__dirname, './data/data.xlsx');
const WINBOX_PATH = path.join(__dirname, './data/winbox.exe');

let mainWindow;
const transfers = new Map(); // resume/cancel state

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 850,
    height: 600,
    autoHideMenuBar: true,
    menuBarVisible: false,
    icon: path.join(__dirname, 'assets', 'Indomaret-Logo-Vector-scaled.ico'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
    }
  });
  mainWindow.loadFile('index.html');
}
app.whenReady().then(() => { try { vpn.init(); } catch (e) { console.error('[vpn] init failed:', e?.message || e); } createWindow(); });

app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });

// === DATA EXCEL ===
ipcMain.handle('get-entries', () => {
  try {
    const wb = xlsx.readFile(DATA_PATH);
    const sheet = wb.Sheets[wb.SheetNames[0]];
    const rawData = xlsx.utils.sheet_to_json(sheet);
    return rawData.map((row, i) => ({
      toko: row.TOKO || row.toko || '',
      nama: row.NAMA || row.nama || '',
      station: row.STATION || row.station || '',
      ip: row.IP || row.ip || '',
      __index: i
    }));
  } catch (e) {
    console.error('[get-entries] ERROR', e);
    return [];
  }
});

ipcMain.handle('add-entry', async (_, newEntry) => {
  try {
    const wb = xlsx.readFile(DATA_PATH);
    const sheetName = wb.SheetNames[0] || 'Sheet1';
    const sheet = wb.Sheets[sheetName] || xlsx.utils.json_to_sheet([]);
    const data = xlsx.utils.sheet_to_json(sheet);

    data.push({
      TOKO: String(newEntry.toko ?? ''),
      NAMA: String(newEntry.nama ?? ''),
      STATION: String(newEntry.station ?? ''),
      IP: String(newEntry.ip ?? '')
    });
    wb.Sheets[sheetName] = xlsx.utils.json_to_sheet(data, { header: ['TOKO','NAMA','STATION','IP'] });
    if (!wb.SheetNames.includes(sheetName)) wb.SheetNames.push(sheetName);
    xlsx.writeFile(wb, DATA_PATH);

    // auto-generate .vnc file jika station numeric
    if (/^\d+$/.test(String(newEntry.station || ''))) {
      const vncPath = path.join(__dirname, 'vnc');
      try { if (!fs.existsSync(vncPath)) fs.mkdirSync(vncPath, { recursive: true }); } catch {}
      const filename = `${newEntry.toko}_${newEntry.station}.vnc`;
      const filePath = path.join(vncPath, filename);
      const vncContent = `[connection]
host=${newEntry.ip}
port=5900
password=A0C7520385EFBFE5D4
`;
      fs.writeFileSync(filePath, vncContent, 'utf8');
    }
    return { ok: true };
  } catch (e) {
    console.error('[add-entry] ERROR', e);
    return { ok: false, error: e.message };
  }
});

ipcMain.handle('delete-entry', async (_, index) => {
  try {
    const wb = xlsx.readFile(DATA_PATH);
    const sheetName = wb.SheetNames[0];
    const sheet = wb.Sheets[sheetName];
    const data = xlsx.utils.sheet_to_json(sheet);
    if (index >= 0 && index < data.length) {
      data.splice(index, 1);
      wb.Sheets[sheetName] = xlsx.utils.json_to_sheet(data, { header: ['TOKO','NAMA','STATION','IP'] });
      xlsx.writeFile(wb, DATA_PATH);
    }
    return { ok: true };
  } catch (e) {
    console.error('[delete-entry] ERROR', e);
    return { ok: false, error: e.message };
  }
});

// === UTIL ===
ipcMain.on('ping', (_, ip) => { exec(`start cmd /k "ping ${ip}"`); });

ipcMain.on('open-vnc', (_, kode, station) => {
  const filename = `${kode}_${station}.vnc`;
  shell.openPath(path.join(__dirname, 'vnc', filename));
});

ipcMain.on('open-winbox', (_, ip, user, pass) => {
  exec(`"${WINBOX_PATH}" ${ip}:8292 ${user} ${pass}`, (err) => { if (err) console.error('[WINBOX ERROR]', err); });
});

ipcMain.handle('get-vnc-files', async () => {
  try {
    const folder = path.join(__dirname, 'vnc');
    if (!fs.existsSync(folder)) return [];
    return fs.readdirSync(folder).filter(f => f.endsWith('.vnc'));
  } catch (e) {
    console.error('[get-vnc-files] ERROR', e);
    return [];
  }
});

ipcMain.handle('update-vnc-password', async (_, filename, newPassword) => {
  try {
    const exePath = path.join(__dirname, 'vnc', 'vncpasswd.exe');
    const targetFile = path.join(__dirname, 'vnc', filename);
    const iniPath = path.join(__dirname, 'vnc', 'UltraVNC.ini');

    if (!fs.existsSync(exePath)) throw new Error('vncpasswd.exe tidak ditemukan');
    if (!fs.existsSync(targetFile)) throw new Error('File VNC tidak ditemukan');

    return await new Promise((resolve, reject) => {
      const child = spawn(exePath, [newPassword], { cwd: path.join(__dirname, 'vnc') });
      child.on('close', (code) => {
        try {
          if (code !== 0 || !fs.existsSync(iniPath)) return reject(new Error('Gagal menghasilkan UltraVNC.ini'));
          const iniContent = fs.readFileSync(iniPath, 'utf8');
          const match = iniContent.match(/passwd=([^\r\n]+)/i);
          if (!match) return reject(new Error('Tidak menemukan nilai password terenkripsi.'));
          const encrypted = match[1].trim();

          try { fs.copyFileSync(targetFile, targetFile + '.bak'); } catch {}
          let content = fs.readFileSync(targetFile, 'utf8');
          content = /^password=.*/mi.test(content)
            ? content.replace(/^password=.*/mi, `password=${encrypted}`)
            : (content + `\npassword=${encrypted}\n`);
          fs.writeFileSync(targetFile, content, 'utf8');
          resolve({ ok: true });
        } catch (err) {
          reject(err);
        }
      });
      child.on('error', reject);
    });
  } catch (e) {
    console.error('[update-vnc-password] ERROR', e);
    return { ok: false, error: e.message };
  }
});

// === FTP ===
async function withFtp(ip, fn) {
  const client = new ftp.Client();
  client.ftp.verbose = false;
  try {
    await client.access({ host: ip, user: 'posterm', password: 'dAZAD9yq', secure: false });
    return await fn(client);
  } finally {
    try { client.close(); } catch {}
  }
}

ipcMain.handle('list-ftp', async (_, ip, cwd = '/') => {
  try {
    return await withFtp(ip, async (client) => {
      await client.cd(cwd);
      const items = await client.list();
      return { cwd, items };
    });
  } catch (err) {
    return { error: err.message };
  }
});

ipcMain.handle('upload-ftp', async (_, { id, ip, cwd='/', resume=true }) => {
  const winRef = BrowserWindow.getFocusedWindow() || mainWindow;
  const pick = await dialog.showOpenDialog(winRef, { properties: ['openFile'] });
  if (pick.canceled || pick.filePaths.length === 0) return { status: 'cancel' };

  const local = pick.filePaths[0];
  const name  = path.basename(local);
  const total = fs.statSync(local).size;

  const client = new ftp.Client();
  client.ftp.verbose = false;

  try {
    await client.access({ host: ip, user: 'posterm', password: 'dAZAD9yq', secure: false });
    await client.cd(cwd);

    let remoteSize = 0;
    if (resume) { try { remoteSize = await client.size(name); } catch {} }
    const offset = Math.min(remoteSize, total);

    transfers.set(id, { client, kind: 'upload', name, offset, total });

    client.trackProgress(info => {
      const sent = offset + info.bytes;
      const pct = Math.max(0, Math.min(100, Math.round((sent / total) * 100)));
      mainWindow?.webContents.send('ftp-progress', { id, dir: 'upload', name, percent: pct });
    });

    if (offset > 0) {
      const rs = fs.createReadStream(local, { start: offset });
      await client.appendFrom(rs, name);
    } else {
      await client.uploadFrom(local, name);
    }

    client.trackProgress();
    transfers.delete(id);
    return { status: 'ok', file: name };
  } catch (err) {
    transfers.delete(id);
    try { client.close(); } catch {}
    return { status: 'error', message: err.message };
  }
});

ipcMain.handle('download-ftp', async (_, { id, ip, remotePath, resume=true }) => {
  const base = path.posix.basename(remotePath);
  const winRef = BrowserWindow.getFocusedWindow() || mainWindow;
  const save = await dialog.showSaveDialog(winRef, { defaultPath: base });
  if (save.canceled || !save.filePath) return { status: 'cancel' };
  const local = save.filePath;

  const client = new ftp.Client();
  client.ftp.verbose = false;

  try {
    await client.access({ host: ip, user: 'posterm', password: 'dAZAD9yq', secure: false });

    const dir  = path.posix.dirname(remotePath);
    const name = path.posix.basename(remotePath);
    await client.cd(dir);
    const list = await client.list();
    const item = list.find(i => i.name === name);
    const total = item?.size ?? 0;

    let offset = 0;
    if (resume && fs.existsSync(local)) { try { offset = fs.statSync(local).size; } catch {} }
    offset = Math.min(offset, total);

    transfers.set(id, { client, kind: 'download', name, offset, total });

    client.trackProgress(info => {
      const received = offset + info.bytes;
      const pct = total ? Math.max(0, Math.min(100, Math.round((received / total) * 100))) : 0;
      mainWindow?.webContents.send('ftp-progress', { id, dir: 'download', name, percent: pct });
    });

    await client.downloadTo(local, name, offset);

    client.trackProgress();
    transfers.delete(id);
    return { status: 'ok', file: name, local };
  } catch (err) {
    transfers.delete(id);
    try { client.close(); } catch {}
    return { status: 'error', message: err.message };
  }
});

ipcMain.handle('delete-ftp', async (_, ip, remotePath, isDir = false) => {
  try {
    return await withFtp(ip, async (client) => {
      if (isDir) await client.removeDir(remotePath);
      else await client.remove(remotePath);
      return { status: 'ok' };
    });
  } catch (err) {
    return { status: 'error', message: err.message };
  }
});

ipcMain.handle('cancel-ftp', async (_, id) => {
  const t = transfers.get(id);
  if (!t) return { status: 'noop' };
  try {
    t.client.close();
    transfers.delete(id);
    return { status: 'ok' };
  } catch (e) {
    return { status: 'error', message: e.message };
  }
});

// Buka WebFig di browser default
ipcMain.on('open-webfig', (_, ip) => {
  try {
    shell.openExternal(`http://${ip}`);
  } catch (e) {
    console.error('[WEBFIG ERROR]', e);
  }
});

// Buka Winbox dengan user/pass sesuai STATION (ambil dari config.json)
ipcMain.on('open-winbox-smart', (_, { ip, station }) => {
  try {
    // fallback user/pass
    let user = 'admin';
    let pass = '';

    if (station === 'RBWDCP' && config.RBWDCP) {
      user = config.RBWDCP.user;
      pass = config.RBWDCP.pass;
    } else if (station === 'RBKONEKSI' && config.RBKONEKSI) {
      user = config.RBKONEKSI.user;
      pass = config.RBKONEKSI.pass;
    }
    const command = `"${WINBOX_PATH}" ${ip}:8292 ${user} ${pass}`;
    exec(command, (err) => {
      if (err) console.error('[WINBOX SMART ERROR]', err);
    });
  } catch (e) {
    console.error('[WINBOX SMART ERROR]', e);
  }
});

// --- helper konversi KI -> angka ---
function kiToDigits(ki = "") {
  const map = {
    A:8,B:8,C:8, D:1,E:1,F:1, G:6,H:6,I:6,
    J:3,K:3,L:3, M:5,N:5,
    P:7,Q:7,R:7, S:4,T:4,U:4,
    V:9,W:9,X:9, Y:2,Z:2
  };
  return [...(ki.toUpperCase().replace(/\s+/g,''))].map(c => /\d/.test(c) ? c : (map[c] ?? '')).join('');
}

// --- DVR auto-login (Basic Auth) ---
ipcMain.on('open-dvr', (_, { ip, toko }) => {
  const user = 'admin';
  const pass = 'IC' + kiToDigits(toko || '');  // contoh: F8HA -> IC1868
  const url  = `http://${ip}:45200`;

  const win = new BrowserWindow({
    width: 1100, height: 720, autoHideMenuBar: true,
    webPreferences: { contextIsolation: true }
  });

  win.webContents.on('login', (event, request, authInfo, callback) => {
    if (!authInfo.isProxy) { event.preventDefault(); callback(user, pass); }
  });

  win.loadURL(url).catch(err => {
    const urlWithCreds = `http://${encodeURIComponent(user)}:${encodeURIComponent(pass)}@${ip}:45200`;
    win.loadURL(urlWithCreds).catch(e => console.error('[DVR ERROR]', e));
  });
});

// === AUTH (tanpa penyimpanan lokal untuk perubahan; dukung GitHub + session override) ===
let sessionOverrideAcc = []; // override sementara (in-memory), tidak ditulis ke disk

function normalizeAccounts(data) {
  let arr;
  if (Array.isArray(data)) arr = data;
  else if (data && typeof data === 'object') {
    const username = String(data.username ?? data.user ?? 'admin').trim();
    const password = String(data.password ?? data.pass ?? 'admin').trim();
    const role     = data.role ? String(data.role).trim() : 'admin';
    arr = [{ username, password, role }];
  } else {
    arr = [{ username: 'admin', password: 'admin', role: 'admin' }];
  }

  return arr
    .map(a => ({
      username: String(a.username ?? a.user ?? '').trim(),
      password: String(a.password ?? a.pass ?? '').trim(),
      role: (a.role ? String(a.role) : 'user').trim(),
      displayName: a.displayName ? String(a.displayName).trim() : undefined,
    }))
    .filter(a => a.username && a.password);
}

// gabung by username (case-insensitive). primary override secondary
function uniqMergeAccounts(primary, secondary) {
  const map = new Map();
  secondary.forEach(a => map.set(String(a.username).toLowerCase(), a));
  primary.forEach(a => map.set(String(a.username).toLowerCase(), { ...map.get(String(a.username).toLowerCase()), ...a }));
  return Array.from(map.values());
}

function readJsonSafe(p) { try { return JSON.parse(fs.readFileSync(p, 'utf-8')); } catch { return null; } }

function fetchGithubRaw(url, timeoutMs = 10000) {
  return new Promise((resolve, reject) => {
    https.get(url, res => {
      if (res.statusCode !== 200) return reject(new Error('HTTP ' + res.statusCode));
      let raw = ''; res.setEncoding('utf8');
      res.on('data', d => raw += d);
      res.on('end', () => resolve(raw));
    }).on('error', reject).setTimeout(timeoutMs, function () { this.destroy(new Error('Request timeout')); });
  });
}

// Sumber akun: (session override) > GitHub (raw) > bundled auth.json
async function loadAccountsFromSources(includeSession = true) {
  const localPackagedPath = path.join(app.isPackaged ? process.resourcesPath : __dirname, 'auth.json');
  const ghRawUrl = 'https://raw.githubusercontent.com/DROISD123/vnc/main/auth.json';

  let ghAcc = [], packagedAcc = [];

  try {
    const raw = await fetchGithubRaw(ghRawUrl);
    ghAcc = normalizeAccounts(JSON.parse(raw));
  } catch {}

  try {
    const j = readJsonSafe(localPackagedPath);
    if (j) packagedAcc = normalizeAccounts(j);
  } catch {}

  let accounts = uniqMergeAccounts(ghAcc, packagedAcc);
  if (includeSession && sessionOverrideAcc.length) {
    accounts = uniqMergeAccounts(sessionOverrideAcc, accounts);
  }
  if (!accounts.length) accounts = normalizeAccounts(null); // fallback admin/admin

  return { accounts, source: { github: !!ghAcc.length, packaged: !!packagedAcc.length, session: !!sessionOverrideAcc.length } };
}

ipcMain.handle('auth:load', async () => {
  const { accounts, source } = await loadAccountsFromSources(true);
  return { ok: true, accounts, source };
});

// Update password untuk sesi berjalan (tidak tulis file)
ipcMain.handle('auth:updatePasswordSession', async (_e, { username, oldPassword, newPassword } = {}) => {
  try {
    if (!username || !newPassword) throw new Error('Data tidak lengkap');

    const { accounts } = await loadAccountsFromSources(true);
    const key = String(username).toLowerCase();
    const found = accounts.find(a => String(a.username).toLowerCase() === key);
    if (!found) throw new Error('User tidak ditemukan');

    if (typeof oldPassword === 'string' && oldPassword.length > 0) {
      if (found.password !== oldPassword) throw new Error('Password lama salah');
    }

    let updated = false;
    sessionOverrideAcc = sessionOverrideAcc.map(a => {
      if (String(a.username).toLowerCase() === key) {
        updated = true;
        return { ...a, password: newPassword };
      }
      return a;
    });
    if (!updated) {
      sessionOverrideAcc.push({
        username: found.username,
        password: newPassword,
        role: found.role,
        displayName: found.displayName
      });
    }

    return { ok: true, note: 'Password di-override untuk sesi ini (tidak disimpan ke disk).' };
  } catch (e) {
    return { ok: false, error: e.message };
  }
});

// ===== GitHub Session Token (NO .env) =====
let GH_TOKEN_SESSION = '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'; // diset dari renderer; tidak dipersist

ipcMain.handle('github:setToken', async (_e, token) => {
  GH_TOKEN_SESSION = String(token || '').trim();
  return { ok: !!GH_TOKEN_SESSION };
});
ipcMain.handle('github:clearToken', async () => {
  GH_TOKEN_SESSION = '';
  return { ok: true };
});

// Owner/repo/path/branch dari config.json (atau default)
const GH_OWNER  = (config.github && config.github.owner)  || 'DROISD123';
const GH_REPO   = (config.github && config.github.repo)   || 'vnc';
const GH_PATH   = (config.github && config.github.path)   || 'auth.json';
const GH_BRANCH = (config.github && config.github.branch) || 'main';

// GitHub API helpers (pakai token sesi)
function ghApiRequest(method, apiPath, bodyObj = null, timeoutMs = 15000) {
  return new Promise((resolve, reject) => {
    const token = GH_TOKEN_SESSION;
    if (!token) return reject(new Error('GitHub token belum diset.'));
    const body = bodyObj ? JSON.stringify(bodyObj) : null;

    const req = https.request({
      hostname: 'api.github.com',
      path: apiPath,
      method,
      headers: {
        'User-Agent': 'electron-app-auth-updater',
        'Authorization': `Bearer ${token}`,
        'Accept': 'application/vnd.github+json',
        'Content-Type': 'application/json',
        ...(body ? { 'Content-Length': Buffer.byteLength(body) } : {})
      }
    }, (res) => {
      let raw = '';
      res.setEncoding('utf8');
      res.on('data', d => raw += d);
      res.on('end', () => {
        if (res.statusCode && res.statusCode >= 200 && res.statusCode < 300) {
          try { resolve(raw ? JSON.parse(raw) : {}); } catch { resolve({}); }
        } else {
          let msg = `GitHub API ${res.statusCode}`;
          try { const j = JSON.parse(raw); if (j && j.message) msg += ': ' + j.message; } catch {}
          reject(new Error(msg));
        }
      });
    });
    req.on('error', reject);
    req.setTimeout(timeoutMs, () => { req.destroy(new Error('GitHub API timeout')); });
    if (body) req.write(body);
    req.end();
  });
}

function encodePathSegments(p) {
  return '/' + p.split('/').map(encodeURIComponent).join('/');
}

async function ghGetFile(owner, repo, filepath, ref) {
  const apiPath = `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/contents${encodePathSegments(filepath)}${ref ? `?ref=${encodeURIComponent(ref)}` : ''}`;
  const res = await ghApiRequest('GET', apiPath, null);
  if (!res || !res.content || !res.sha) throw new Error('Gagal membaca isi file dari GitHub.');
  const decoded = Buffer.from(res.content, 'base64').toString('utf8');
  return { sha: res.sha, text: decoded };
}

async function ghPutFile(owner, repo, filepath, message, textContent, sha, branch) {
  const apiPath = `/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/contents${encodePathSegments(filepath)}`;
  const contentB64 = Buffer.from(textContent, 'utf8').toString('base64');
  const body = { message, content: contentB64, sha, ...(branch ? { branch } : {}) };
  const res = await ghApiRequest('PUT', apiPath, body);
  return res && res.content && res.commit ? res : null;
}

// === Perubahan password permanen (commit ke GitHub) ===
ipcMain.handle('auth:changePassword', async (_e, { username, oldPassword, newPassword } = {}) => {
  try {
    if (!username || !newPassword) throw new Error('Data tidak lengkap');

    // 1) Ambil file dari GitHub (branch yang di-set)
    const { sha, text } = await ghGetFile(GH_OWNER, GH_REPO, GH_PATH, GH_BRANCH);

    // 2) Parse & update akun
    let json;
    try { json = JSON.parse(text); } catch { throw new Error('auth.json di GitHub bukan JSON valid'); }
    let accounts = normalizeAccounts(json);

    const key = String(username).toLowerCase();
    const found = accounts.find(a => String(a.username).toLowerCase() === key);
    if (!found) throw new Error('User tidak ditemukan di GitHub');

    if (typeof oldPassword === 'string' && oldPassword.length > 0) {
      if (found.password !== oldPassword) throw new Error('Password lama salah');
    }

    accounts = accounts.map(a => (String(a.username).toLowerCase() === key
      ? { ...a, password: newPassword }
      : a
    ));

    // 3) Tulis balik ke GitHub
    const pretty = JSON.stringify(accounts, null, 2) + '\n';
    const msg = `chore(auth): change password for ${found.username} via app`;
    const putRes = await ghPutFile(GH_OWNER, GH_REPO, GH_PATH, msg, pretty, sha, GH_BRANCH);
    if (!putRes) throw new Error('Gagal commit ke GitHub');

    // 4) Sinkronkan ke sesi berjalan supaya langsung berlaku
    let updated = false;
    sessionOverrideAcc = sessionOverrideAcc.map(a => {
      if (String(a.username).toLowerCase() === key) {
        updated = true;
        return { ...a, password: newPassword };
      }
      return a;
    });
    if (!updated) {
      sessionOverrideAcc.push({
        username: found.username,
        password: newPassword,
        role: found.role,
        displayName: found.displayName
      });
    }

    return {
      ok: true,
      committed: true,
      repo: `${GH_OWNER}/${GH_REPO}`,
      path: GH_PATH,
      branch: GH_BRANCH
    };
  } catch (e) {
    return { ok: false, error: e.message };
  }
});

// ===== LOG activity (append JSONL ke userData) =====
ipcMain.handle('activity:log', async (_e, payload = {}) => {
  try {
    const userDataDir = app.getPath('userData');
    const logPath = path.join(userDataDir, 'activity.log');
    const rec = {
      ts: new Date().toISOString(),
      user: String(payload.user || '').trim(),
      action: String(payload.action || '').trim(),
      detail: payload.detail ?? null,
    };
    fs.appendFileSync(logPath, JSON.stringify(rec) + '\n');
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e.message };
  }
});

// ===== FileZilla helper =====
ipcMain.handle('open-filezilla', async (_evt, opts = {}) => {
  try {
    const host = opts.host;
    if (!host) throw new Error('host kosong');

    const protocol = opts.protocol || 'ftp';
    const user = opts.user;
    const pass = opts.pass;
    const port = opts.port;

    // ftp://[user[:pass]@]host[:port]
    let url = `${protocol}://`;
    if (user) {
      url += encodeURIComponent(user);
      if (pass) url += ':' + encodeURIComponent(pass);
      url += '@';
    }
    url += host;
    if (port) url += ':' + port;

    const candidates = process.platform === 'win32'
      ? [
          'filezilla',
          'C:\\Program Files\\FileZilla FTP Client\\filezilla.exe',
          'C:\\Program Files (x86)\\FileZilla FTP Client\\filezilla.exe',
        ]
      : ['filezilla'];

    let exe = candidates[0];
    for (const c of candidates) {
      try { if (fs.existsSync(c)) { exe = c; break; } } catch {}
    }

    const p = spawn(exe, [url], { detached: true, stdio: 'ignore' });
    p.unref();
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e.message };
  }
});

// === About Dialog ===
ipcMain.on('app:about', () => {
  const version = app.getVersion ? app.getVersion() : 'dev';
  dialog.showMessageBox({
    type: 'info',
    title: 'About',
    message: 'VNC Launcher',
    detail: `Version: ${version}\nOS: ${process.platform} ${process.arch}\nElectron: ${process.versions.electron}\nNode: ${process.versions.node}`,
    buttons: ['OK']
  });
});

// === Close App ===
ipcMain.on('app:close', () => app.quit());

// === App Info (untuk modal user) ===
ipcMain.handle('app:getInfo', () => ({
  version: app.getVersion ? app.getVersion() : '-',
  os: `${process.platform} ${process.arch}`,
}));

ipcMain.handle('app:getLocalVersion', () => ({
  version: String(localVersion?.version || '0.0.0'),
  build: localVersion?.build || null,
  notes: localVersion?.notes || null
}));

app.whenReady().then(async () => { registerUpdateIPC(); })