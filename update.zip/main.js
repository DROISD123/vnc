const { app, BrowserWindow, ipcMain, shell, dialog } = require('electron');
const path = require('path');
const fs = require('fs');
const xlsx = require('xlsx');
const { exec, spawn } = require('child_process');
const ftp = require('basic-ftp'); // FTP

// === KONFIG ===
const CONFIG_PATH = path.join(__dirname, 'config.json');
const config = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));
const DATA_PATH = path.join(__dirname, './data/data.xlsx');
const WINBOX_PATH = path.join(__dirname, './data/winbox.exe');

let mainWindow;
const transfers = new Map(); // resume/cancel state

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 850,
    height: 600,
    autoHideMenuBar: true,
    menuBarVisible: false,
    icon: path.join(__dirname, 'assets', 'Indomaret-Logo-Vector-scaled.ico'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
    }
  });
  mainWindow.loadFile('index.html');
}
app.whenReady().then(createWindow);

// === DATA EXCEL ===
ipcMain.handle('get-entries', () => {
  const wb = xlsx.readFile(DATA_PATH);
  const sheet = wb.Sheets[wb.SheetNames[0]];
  const rawData = xlsx.utils.sheet_to_json(sheet);
  return rawData.map((row, i) => ({
    toko: row.TOKO || row.toko || '',
    nama: row.NAMA || row.nama || '',
    station: row.STATION || row.station || '',
    ip: row.IP || row.ip || '',
    __index: i
  }));
});

ipcMain.handle('add-entry', async (_, newEntry) => {
  const wb = xlsx.readFile(DATA_PATH);
  const sheetName = wb.SheetNames[0];
  const sheet = wb.Sheets[sheetName];
  const data = xlsx.utils.sheet_to_json(sheet);

  data.push({ TOKO: newEntry.toko, NAMA: newEntry.nama, STATION: newEntry.station, IP: newEntry.ip });
  wb.Sheets[sheetName] = xlsx.utils.json_to_sheet(data, { header: ['TOKO','NAMA','STATION','IP'] });
  xlsx.writeFile(wb, DATA_PATH);

  if (/^\d+$/.test(newEntry.station)) {
    const vncPath = path.join(__dirname, 'vnc');
    const filename = `${newEntry.toko}_${newEntry.station}.vnc`;
    const filePath = path.join(vncPath, filename);
    const vncContent = `[connection]
host=${newEntry.ip}
port=5900
password=A0C7520385EFBFE5D4
`;
    fs.writeFileSync(filePath, vncContent, 'utf8');
  }
});

ipcMain.handle('delete-entry', async (_, index) => {
  const wb = xlsx.readFile(DATA_PATH);
  const sheetName = wb.SheetNames[0];
  const sheet = wb.Sheets[sheetName];
  const data = xlsx.utils.sheet_to_json(sheet);
  if (index >= 0 && index < data.length) {
    data.splice(index, 1);
    wb.Sheets[sheetName] = xlsx.utils.json_to_sheet(data);
    xlsx.writeFile(wb, DATA_PATH);
  }
});

// === UTIL ===
ipcMain.on('ping', (_, ip) => { exec(`start cmd /k "ping ${ip}"`); });
ipcMain.on('open-dvr', (_, ip) => shell.openExternal(`http://${ip}:45200`));
ipcMain.on('open-vnc', (_, kode, station) => {
  const filename = `${kode}_${station}.vnc`;
  shell.openPath(path.join(__dirname, 'vnc', filename));
});
ipcMain.on('open-winbox', (_, ip, user, pass) => {
  exec(`"${WINBOX_PATH}" ${ip}:8292 ${user} ${pass}`, (err) => { if (err) console.error('[WINBOX ERROR]', err); });
});

ipcMain.handle('get-vnc-files', async () => {
  const folder = path.join(__dirname, 'vnc');
  return fs.readdirSync(folder).filter(f => f.endsWith('.vnc'));
});

ipcMain.handle('update-vnc-password', async (_, filename, newPassword) => {
  const exePath = path.join(__dirname, 'vnc', 'vncpasswd.exe');
  const targetFile = path.join(__dirname, 'vnc', filename);
  const iniPath = path.join(__dirname, 'vnc', 'UltraVNC.ini');

  return new Promise((resolve, reject) => {
    const child = spawn(exePath, [newPassword], { cwd: path.join(__dirname, 'vnc') });
    child.on('close', (code) => {
      if (code !== 0 || !fs.existsSync(iniPath)) return reject(new Error('Gagal menghasilkan UltraVNC.ini'));
      const iniContent = fs.readFileSync(iniPath, 'utf8');
      const match = iniContent.match(/passwd=([^\r\n]+)/i);
      if (!match) return reject(new Error('Tidak menemukan nilai password terenkripsi.'));
      const encrypted = match[1].trim();

      try { fs.copyFileSync(targetFile, targetFile + '.bak'); } catch (e) {}
      let content = fs.readFileSync(targetFile, 'utf8');
      content = /^password=.*/mi.test(content) ? content.replace(/^password=.*/mi, `password=${encrypted}`) : (content + `\npassword=${encrypted}\n`);
      fs.writeFileSync(targetFile, content, 'utf8');
      resolve();
    });
  });
});

app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });

// === FTP ===
async function withFtp(ip, fn) {
  const client = new ftp.Client();
  client.ftp.verbose = false;
  try {
    await client.access({ host: ip, user: 'posterm', password: 'dAZAD9yq', secure: false });
    return await fn(client);
  } finally {
    client.close();
  }
}

ipcMain.handle('list-ftp', async (_, ip, cwd = '/') => {
  try {
    return await withFtp(ip, async (client) => {
      await client.cd(cwd);
      const items = await client.list();
      return { cwd, items };
    });
  } catch (err) {
    return { error: err.message };
  }
});

ipcMain.handle('upload-ftp', async (_, { id, ip, cwd='/', resume=true }) => {
  const pick = await dialog.showOpenDialog(BrowserWindow.getFocusedWindow(), { properties: ['openFile'] });
  if (pick.canceled || pick.filePaths.length === 0) return { status: 'cancel' };

  const local = pick.filePaths[0];
  const name  = path.basename(local);
  const total = fs.statSync(local).size;

  const client = new ftp.Client();
  client.ftp.verbose = false;

  try {
    await client.access({ host: ip, user: 'posterm', password: 'dAZAD9yq', secure: false });
    await client.cd(cwd);

    let remoteSize = 0;
    if (resume) { try { remoteSize = await client.size(name); } catch {} }
    const offset = Math.min(remoteSize, total);

    transfers.set(id, { client, kind: 'upload', name, offset, total });

    client.trackProgress(info => {
      const sent = offset + info.bytes;
      const pct = Math.max(0, Math.min(100, Math.round((sent / total) * 100)));
      mainWindow?.webContents.send('ftp-progress', { id, dir: 'upload', name, percent: pct });
    });

    if (offset > 0) {
      const rs = fs.createReadStream(local, { start: offset });
      await client.appendFrom(rs, name);
    } else {
      await client.uploadFrom(local, name);
    }

    client.trackProgress();
    transfers.delete(id);
    return { status: 'ok', file: name };
  } catch (err) {
    transfers.delete(id);
    try { client.close(); } catch {}
    return { status: 'error', message: err.message };
  }
});

ipcMain.handle('download-ftp', async (_, { id, ip, remotePath, resume=true }) => {
  const base = path.posix.basename(remotePath);
  const save = await dialog.showSaveDialog(BrowserWindow.getFocusedWindow(), { defaultPath: base });
  if (save.canceled || !save.filePath) return { status: 'cancel' };
  const local = save.filePath;

  const client = new ftp.Client();
  client.ftp.verbose = false;

  try {
    await client.access({ host: ip, user: 'posterm', password: 'dAZAD9yq', secure: false });

    const dir  = path.posix.dirname(remotePath);
    const name = path.posix.basename(remotePath);
    await client.cd(dir);
    const list = await client.list();
    const item = list.find(i => i.name === name);
    const total = item?.size ?? 0;

    let offset = 0;
    if (resume && fs.existsSync(local)) { try { offset = fs.statSync(local).size; } catch {} }
    offset = Math.min(offset, total);

    transfers.set(id, { client, kind: 'download', name, offset, total });

    client.trackProgress(info => {
      const received = offset + info.bytes;
      const pct = total ? Math.max(0, Math.min(100, Math.round((received / total) * 100))) : 0;
      mainWindow?.webContents.send('ftp-progress', { id, dir: 'download', name, percent: pct });
    });

    await client.downloadTo(local, name, offset);

    client.trackProgress();
    transfers.delete(id);
    return { status: 'ok', file: name, local };
  } catch (err) {
    transfers.delete(id);
    try { client.close(); } catch {}
    return { status: 'error', message: err.message };
  }
});

ipcMain.handle('delete-ftp', async (_, ip, remotePath, isDir = false) => {
  try {
    return await withFtp(ip, async (client) => {
      if (isDir) await client.removeDir(remotePath);
      else await client.remove(remotePath);
      return { status: 'ok' };
    });
  } catch (err) {
    return { status: 'error', message: err.message };
  }
});

ipcMain.handle('cancel-ftp', async (_, id) => {
  const t = transfers.get(id);
  if (!t) return { status: 'noop' };
  try {
    t.client.close();
    transfers.delete(id);
    return { status: 'ok' };
  } catch (e) {
    return { status: 'error', message: e.message };
  }
});
// Buka WebFig di browser default
ipcMain.on('open-webfig', (_, ip) => {
  try {
    shell.openExternal(`http://${ip}`);
  } catch (e) {
    console.error('[WEBFIG ERROR]', e);
  }
});

// Buka Winbox dengan user/pass sesuai STATION (ambil dari config.json)
ipcMain.on('open-winbox-smart', (_, { ip, station }) => {
  try {
    // fallback user/pass
    let user = 'admin';
    let pass = '';

    if (station === 'RBWDCP' && config.RBWDCP) {
      user = config.RBWDCP.user;
      pass = config.RBWDCP.pass;
    } else if (station === 'RBKONEKSI' && config.RBKONEKSI) {
      user = config.RBKONEKSI.user;
      pass = config.RBKONEKSI.pass;
    }
    const command = `"${WINBOX_PATH}" ${ip}:8292 ${user} ${pass}`;
    exec(command, (err) => {
      if (err) console.error('[WINBOX SMART ERROR]', err);
    });
  } catch (e) {
    console.error('[WINBOX SMART ERROR]', e);
  }
});
