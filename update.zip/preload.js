// preload.js — hardened, with unsubscribe helpers (drop-in replacement)
const { contextBridge, ipcRenderer } = require('electron');

/* ---------- small helpers ---------- */
const safeInvoke = (ch, ...args) => ipcRenderer.invoke(ch, ...args);
const safeSend   = (ch, ...args) => ipcRenderer.send(ch, ...args);

// subscribe helper that returns an unsubscribe function
const on = (channel, cb) => {
  if (typeof cb !== 'function') return () => {};
  const wrapped = (_e, data) => {
    try { cb(data); } catch { /* ignore listener errors */ }
  };
  ipcRenderer.on(channel, wrapped);
  return () => ipcRenderer.off(channel, wrapped);
};

// same as on(), but passes all args (for future extensibility)
const onAny = (channel, cb) => {
  if (typeof cb !== 'function') return () => {};
  const wrapped = (_e, ...args) => {
    try { cb(...args); } catch { /* ignore */ }
  };
  ipcRenderer.on(channel, wrapped);
  return () => ipcRenderer.off(channel, wrapped);
};

/* ---------- electronAPI ---------- */
const electronAPI = Object.freeze({
  // Data/listing
  getEntries:            ()                => safeInvoke('get-entries'),
  addEntry:              (entry)           => safeInvoke('add-entry', entry),
  deleteEntry:           (index)           => safeInvoke('delete-entry', index),

  // Aksi umum (IPC fire-and-forget)
  openVnc:               (kode, station)   => safeSend('open-vnc', kode, station),
  openWinbox:            (ip, user, pass)  => safeSend('open-winbox', ip, user, pass),
  ping:                  (ip)              => safeSend('ping', ip),
  openDvr:               (ip, toko)        => safeSend('open-dvr', { ip, toko }),
  openWebfig:            (ip)              => safeSend('open-webfig', ip),
  openWinboxSmart:       (ip, station)     => safeSend('open-winbox-smart', { ip, station }),

  // VNC password
  getVncFiles:           ()                => safeInvoke('get-vnc-files'),
  updateVncPassword:     (filename, pw)    => safeInvoke('update-vnc-password', filename, pw),

  // FTP
  listFtp:               (ip, cwd)                         => safeInvoke('list-ftp', ip, cwd),
  uploadFtp:             (id, ip, cwd, resume = true)      => safeInvoke('upload-ftp',   { id, ip, cwd, resume }),
  downloadFtp:           (id, ip, remotePath, resume=true) => safeInvoke('download-ftp', { id, ip, remotePath, resume }),
  deleteFtp:             (ip, remotePath, isDir)           => safeInvoke('delete-ftp',   ip, remotePath, isDir),
  cancelFtp:             (id)                              => safeInvoke('cancel-ftp',   id),
  onFtpProgress:         (cb)                              => onAny('ftp-progress', cb),
  openFileZilla:         (opts)                            => safeInvoke('open-filezilla', opts),
openExternal:           (url)              => safeInvoke('open-external', url),

  // Auth & activity
  getAuth:               ()                => safeInvoke('auth:load'),
  logActivity:           (payload)         => safeInvoke('activity:log', payload),

  // Password — permanen (commit ke GitHub)
  changePassword:        (args)            => safeInvoke('auth:changePassword', args),

  // Password — sementara (in-memory)
  updatePasswordSession: (args)            => safeInvoke('auth:updatePasswordSession', args),

  // GitHub token sesi (NO .env, jangan log token!)
  setGithubToken:        (token)           => safeInvoke('github:setToken', token),
  clearGithubToken:      ()                => safeInvoke('github:clearToken'),

  // Update & about
  runUpdate:             ()                => safeSend('open-update'),
  aboutApp:              ()                => safeSend('app:about'),
  closeApp:              ()                => safeSend('app:close'),
  getAppInfo:            ()                => safeInvoke('app:getInfo'),
  

  // ===== VPN APIs =====
  openVpnWindow:         ()                => safeSend('vpn:open-window'),
  closeVpnWindow:        ()                => safeSend('vpn:close-window'),
  minimizeVpnWindow:     ()                => safeSend('vpn:minimize-window'),
  getVpnAlwaysOnTop:     ()                => safeInvoke('vpn:get-ontop'),
  toggleVpnAlwaysOnTop:  ()                => safeInvoke('vpn:toggle-ontop'),
  vpnLoadList:           ()                => safeInvoke('vpn:load-list'),
  vpnConnect:            (cfg)             => safeInvoke('vpn:connect', cfg),
  vpnDisconnect:         ()                => safeInvoke('vpn:disconnect'),
  onVpnLog:              (cb)              => on('vpn:log', cb),

  // Window controls (titlebar custom)
  winMinimize:           ()                => safeInvoke('win:minimize'),
  winToggleMaximize:     ()                => safeInvoke('win:toggleMaximize'),
  winClose:              ()                => safeInvoke('win:close'),
  onWinState:            (cb)              => on('win-state', cb),
    openSqlYog:           (opts)            => safeSend('open-sqlyog', opts),

});

contextBridge.exposeInMainWorld('electronAPI', electronAPI);

/* ---------- updateAPI ---------- */
const updateAPI = Object.freeze({
  check:       ()                   => safeInvoke('update:check'),
  download:    (url)                => safeInvoke('update:download', { url }),
  apply:       (zipPath)            => safeInvoke('update:apply', { zipPath }),
  onProgress:  (cb)                 => on('update:progress', cb), // returns unsubscribe
  onLog:       (cb)                 => on('update:log', cb),      // returns unsubscribe
});
contextBridge.exposeInMainWorld('updateAPI', updateAPI);

/* ---------- versionAPI ---------- */
const versionAPI = Object.freeze({
  get: () => safeInvoke('app:getLocalVersion')
});
contextBridge.exposeInMainWorld('versionAPI', versionAPI);

/* ---------- elevation alias (tetap dipertahankan untuk kompatibilitas) ---------- */
contextBridge.exposeInMainWorld('applyToInstallWithElevation', (zipPath) =>
  safeInvoke('update:apply', { zipPath })
);

