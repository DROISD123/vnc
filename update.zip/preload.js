// preload.js — FULL (expose IPC termasuk set/clear token GitHub sesi)

const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  // Data/listing
  getEntries: () => ipcRenderer.invoke('get-entries'),
  addEntry: (entry) => ipcRenderer.invoke('add-entry', entry),
  deleteEntry: (index) => ipcRenderer.invoke('delete-entry', index),

  // Aksi umum
  openVnc: (kode, station) => ipcRenderer.send('open-vnc', kode, station),
  openWinbox: (ip, user, pass) => ipcRenderer.send('open-winbox', ip, user, pass),
  ping: (ip) => ipcRenderer.send('ping', ip),
  openDvr: (ip, toko) => ipcRenderer.send('open-dvr', { ip, toko }),
  openWebfig: (ip) => ipcRenderer.send('open-webfig', ip),
  openWinboxSmart: (ip, station) => ipcRenderer.send('open-winbox-smart', { ip, station }),

  // VNC password
  getVncFiles: () => ipcRenderer.invoke('get-vnc-files'),
  updateVncPassword: (filename, password) => ipcRenderer.invoke('update-vnc-password', filename, password),

  // FTP
  listFtp:     (ip, cwd) => ipcRenderer.invoke('list-ftp', ip, cwd),
  uploadFtp:   (id, ip, cwd, resume = true) => ipcRenderer.invoke('upload-ftp', { id, ip, cwd, resume }),
  downloadFtp: (id, ip, remotePath, resume = true) => ipcRenderer.invoke('download-ftp', { id, ip, remotePath, resume }),
  deleteFtp:   (ip, remotePath, isDir) => ipcRenderer.invoke('delete-ftp', ip, remotePath, isDir),
  cancelFtp:   (id) => ipcRenderer.invoke('cancel-ftp', id),
  onFtpProgress: (cb) => ipcRenderer.on('ftp-progress', (_e, data) => cb?.(data)),
  openFileZilla: (opts) => ipcRenderer.invoke('open-filezilla', opts),

  // Auth
  getAuth: () => ipcRenderer.invoke('auth:load'),
  logActivity: (payload) => ipcRenderer.invoke('activity:log', payload),

  // Password — permanen (commit ke GitHub)
  changePassword: (args) => ipcRenderer.invoke('auth:changePassword', args),

  // Password — sementara (in-memory)
  updatePasswordSession: (args) => ipcRenderer.invoke('auth:updatePasswordSession', args),

  // GitHub token sesi (NO .env)
  setGithubToken: (token) => ipcRenderer.invoke('github:setToken', token),
  clearGithubToken: () => ipcRenderer.invoke('github:clearToken'),
  runUpdate: () => ipcRenderer.send('open-update'),
  aboutApp:  () => ipcRenderer.send('app:about'),
  closeApp:  () => ipcRenderer.send('app:close'),
  getAppInfo: () => ipcRenderer.invoke('app:getInfo'),
});


contextBridge.exposeInMainWorld('updateAPI', {
  check:      () => ipcRenderer.invoke('update:check'),
  download:   (url) => ipcRenderer.invoke('update:download', { url }),
  apply:      (zipPath) => ipcRenderer.invoke('update:apply', { zipPath }),
  onProgress: (cb) => ipcRenderer.on('update:progress', (_e, p) => cb && cb(p)),
  onLog:      (cb) => ipcRenderer.on('update:log', (_e, m) => cb && cb(m)),
});
contextBridge.exposeInMainWorld('versionAPI', {
  get: () => ipcRenderer.invoke('app:getLocalVersion')
});
contextBridge.exposeInMainWorld('applyToInstallWithElevation', (zipPath) =>
  ipcRenderer.invoke('update:apply', { zipPath })
);