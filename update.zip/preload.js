const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  // data/listing
  getEntries: () => ipcRenderer.invoke('get-entries'),
  addEntry: (entry) => ipcRenderer.invoke('add-entry', entry),
  deleteEntry: (index) => ipcRenderer.invoke('delete-entry', index),

  // aksi
  openVnc: (kode, station) => ipcRenderer.send('open-vnc', kode, station),
  openWinbox: (ip, user, pass) => ipcRenderer.send('open-winbox', ip, user, pass),
  openFtp: (ip) => ipcRenderer.send('open-ftp', ip),
  ping: (ip) => ipcRenderer.send('ping', ip),
  openDvr: (ip) => ipcRenderer.send('open-dvr', ip),

  // vnc password
  getVncFiles: () => ipcRenderer.invoke('get-vnc-files'),
  updateVncPassword: (filename, password) => ipcRenderer.invoke('update-vnc-password', filename, password),

  // FTP (lengkap)
  listFtp:     (ip, cwd)                        => ipcRenderer.invoke('list-ftp', ip, cwd),
  uploadFtp:   (id, ip, cwd, resume = true)     => ipcRenderer.invoke('upload-ftp', { id, ip, cwd, resume }),
  downloadFtp: (id, ip, remotePath, resume=true)=> ipcRenderer.invoke('download-ftp', { id, ip, remotePath, resume }),
  deleteFtp:   (ip, remotePath, isDir)          => ipcRenderer.invoke('delete-ftp', ip, remotePath, isDir),
  cancelFtp:   (id)                              => ipcRenderer.invoke('cancel-ftp', id),
  onFtpProgress: (cb) => ipcRenderer.on('ftp-progress', (_, data) => cb?.(data)),
  openWebfig: (ip) => ipcRenderer.send('open-webfig', ip),
  openWinboxSmart: (ip, station) => ipcRenderer.send('open-winbox-smart', { ip, station }),
});
