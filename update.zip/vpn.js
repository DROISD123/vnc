// vpn.js — Modul VPN (PPTP/L2TP) untuk proses main Electron (refactor + fix rasdial 623)
const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');
const fs = require('fs');
const https = require('https');
const { exec } = require('child_process');

const REMOTE_VPN_URL = 'https://raw.githubusercontent.com/DROISD123/vnc/main/vpn.json';

let vpnWin = null;
let _initialized = false;

// ===== Util =====
function sendLog(msg) { try { if (vpnWin && !vpnWin.isDestroyed()) vpnWin.webContents.send('vpn:log', String(msg)); } catch {} }
function fetchJson(url) {
  return new Promise((resolve, reject) => {
    try {
      https.get(url, { headers: { 'User-Agent': 'vnc-launcher' } }, (res) => {
        if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) return fetchJson(res.headers.location).then(resolve, reject);
        if (!res.statusCode || res.statusCode < 200 || res.statusCode >= 300) return reject(new Error(`HTTP ${res.statusCode || 'ERR'}`));
        let raw = ''; res.setEncoding('utf8'); res.on('data', d => raw += d);
        res.on('end', () => { try { resolve(JSON.parse(raw)); } catch (e) { reject(new Error('JSON parse error: ' + (e?.message || e))); } });
      }).on('error', reject);
    } catch (e) { reject(e); }
  });
}
function extractArray(data){
  try{
    if (Array.isArray(data)) return data;
    if (!data || typeof data !== 'object') return [];
    const keys = ['items','profiles','vpn','vpns','list','data','result','results'];
    for (const k of keys) {
      const v = data[k];
      if (Array.isArray(v)) return v;
      if (v && typeof v === 'object') {
        const inner = extractArray(v);
        if (Array.isArray(inner) && inner.length) return inner;
      }
    }
    for (const k of Object.keys(data)) { if (Array.isArray(data[k])) return data[k]; }
  } catch {}
  return [];
}
function normalizeProto(p){ const x=String(p||'').toLowerCase().trim(); return (x==='l2tp'||x==='pptp')?x:'pptp'; }

// ===== Profiles =====
function getCacheFile(){ return path.join(app.getPath('userData'), 'vpn-cache.json'); }
function readLocalVpnJson(){
  const candidates=[ path.join(__dirname,'vpn.json'), path.join(app.getPath('userData'),'vpn.json'),
    (app.isPackaged?path.join(process.resourcesPath,'app.asar.unpacked','vpn.json'):null),
    (app.isPackaged?path.join(process.resourcesPath,'app','vpn.json'):null) ].filter(Boolean);
  for(const f of candidates){
    try{
      if (fs.existsSync(f)) {
        const obj = JSON.parse(fs.readFileSync(f,'utf8'));
        return { items: extractArray(obj), path: f };
      }
    } catch {}
  }
  return null;
}
async function loadProfilesOnline(){ const data=await fetchJson(REMOTE_VPN_URL); const items=extractArray(data); try{ fs.writeFileSync(getCacheFile(), JSON.stringify(data)); }catch{} return { items, source:'Online' }; }
function loadProfilesCache(){
  const f = getCacheFile();
  if (!fs.existsSync(f)) return null;
  try{
    const cached = JSON.parse(fs.readFileSync(f,'utf8'));
    return { items: extractArray(cached), source:'Cache' };
  } catch(e){
    sendLog('[VPN] cache read error: ' + (e?.message || e));
    return null;
  }
}
function loadProfilesLocal(){ const res=readLocalVpnJson(); return res?{ items: res.items, source:'Local' }:null; }
async function loadProfiles(){ try{ return await loadProfilesOnline(); }catch(e){ sendLog('[VPN] online failed: '+(e?.message||e)); } const c=loadProfilesCache(); if(c) return c; const l=loadProfilesLocal(); if(l) return l; return { items:[], source:'Offline' }; }

// ===== Window =====
function getWindowStateFile(){ return path.join(app.getPath('userData'),'vpn-window.json'); }
function loadWindowState(){
  const d = { width:760, height:560, x:undefined, y:undefined, alwaysOnTop:false };
  try{
    const f = getWindowStateFile();
    if (fs.existsSync(f)) return { ...d, ...JSON.parse(fs.readFileSync(f,'utf8')) };
  } catch {}
  return d;
}
function saveWindowState(win){
  try{
    const b = win.getBounds();
    const payload = { width:b.width, height:b.height, x:b.x, y:b.y, alwaysOnTop:win.isAlwaysOnTop() };
    fs.writeFileSync(getWindowStateFile(), JSON.stringify(payload));
  } catch {}
}
function buildVpnWindow(o){
  return new BrowserWindow({
    width:o.width, height:o.height, x:o.x, y:o.y, title:'VPN',
    autoHideMenuBar:true, resizable:true, frame:false, transparent:false, hasShadow:true, show:false,
    backgroundColor:'#111827',
    webPreferences:{ contextIsolation:true, nodeIntegration:false, preload:path.join(__dirname,'preload.js') }
  });
}
function openVpnWindow(){
  try{
    const state = loadWindowState();
    if (vpnWin && !vpnWin.isDestroyed()){ vpnWin.show(); vpnWin.focus(); return; }
    vpnWin = buildVpnWindow(state);
    vpnWin.on('close', () => saveWindowState(vpnWin));
    vpnWin.on('closed', () => { vpnWin = null; });
    vpnWin.once('ready-to-show', () => vpnWin.show());
    try{ vpnWin.setAlwaysOnTop(!!state.alwaysOnTop); }catch{}
    vpnWin.loadFile(path.join(__dirname,'vpn.html'));
  } catch(e){ sendLog('[VPN] open window error: ' + (e?.message || e)); }
}

// ===== PowerShell + RAS helpers =====
// Jalankan PowerShell sebagai file .ps1 (hindari escape/parse error)
function runPS(scriptText) {
  return new Promise((resolve, reject) => {
    try {
      const psPath = path.join(app.getPath('userData'), `ps-${Date.now()}.ps1`);
      fs.writeFileSync(psPath, scriptText, 'utf8');
      const cmd = `powershell -NoProfile -ExecutionPolicy Bypass -File "${psPath}"`;
      exec(cmd, { windowsHide: true }, (err, stdout, stderr) => {
        try { fs.unlinkSync(psPath); } catch {}
        if (err) {
          const msg = `${stderr || ''}${stdout || ''}`.trim() || err.message;
          return reject(new Error(msg));
        }
        resolve(stdout || 'OK');
      });
    } catch (e) { reject(e); }
  });
}

function runRAS(cmd) {
  return new Promise((resolve, reject) => {
    exec(cmd, { windowsHide: true }, (err, stdout, stderr) => {
      if (err) {
        const msg = `${stderr || ''}${stdout || ''}`.trim() || err.message;
        return reject(new Error(msg));
      }
      resolve(stdout || 'OK');
    });
  });
}

// ===== Phonebook handling (fix rasdial 623) =====
const SYSTEM_PBK = 'C:\\ProgramData\\Microsoft\\Network\\Connections\\Pbk\\rasphone.pbk';
const USER_PBK   = process.env.APPDATA ? path.join(process.env.APPDATA, 'Microsoft\\Network\\Connections\\Pbk\\rasphone.pbk') : '';

function buildRasdialCmd(name, username, password, phonebookPath) {
  const u = username ? ` "${String(username)}"` : '';
  const p = password ? ` "${String(password)}"` : '';
  const pbk = phonebookPath ? ` /phonebook:"${phonebookPath}"` : '';
  return `rasdial "${name}"${u}${p}${pbk}`;
}

async function getVpnScope(name) {
  const n = String(name || '').replace(/"/g,'');
  const ps = (`
$c = Get-VpnConnection -Name "${n}" -ErrorAction SilentlyContinue
if (-not $c) { 'none' } else { if ($c.AllUserConnection) { 'system' } else { 'user' } }
  `).trim();
  try {
    const out = await runPS(ps);
    const s = String(out || '').toLowerCase();
    if (s.includes('system')) return 'system';
    if (s.includes('user'))   return 'user';
    return 'none';
  } catch {
    return 'none';
  }
}

function sleep(ms){ return new Promise(r=>setTimeout(r,ms)); }

async function dialWithFallback(name, username, password) {
  try {
    // default: user phonebook implisit
    return await runRAS(buildRasdialCmd(name, username, password));
  } catch (e1) {
    if (!/(\b| )623(\b| )/.test(String(e1.message))) throw e1;
    const scope = await getVpnScope(name);
    if (scope === 'system') {
      try { return await runRAS(buildRasdialCmd(name, username, password, SYSTEM_PBK)); }
      catch (e2) {
        if (!/(\b| )623(\b| )/.test(String(e2.message))) throw e2;
        if (USER_PBK) return await runRAS(buildRasdialCmd(name, username, password, USER_PBK));
        throw e2;
      }
    } else if (scope === 'user') {
      try { return await runRAS(buildRasdialCmd(name, username, password, USER_PBK)); }
      catch (e3) {
        if (!/(\b| )623(\b| )/.test(String(e3.message))) throw e3;
        return await runRAS(buildRasdialCmd(name, username, password, SYSTEM_PBK));
      }
    } else {
      // entri belum committed ke phonebook → jeda & coba lagi default
      await sleep(600);
      return await runRAS(buildRasdialCmd(name, username, password));
    }
  }
}

// ===== Build & ensure profile =====
function buildAddVpnCommand({ proto, server, name, psk, allUser }) {
  // Sanitize nama: hilangkan kutip & ganti EN/EM dash ke '-'
  const rawName   = String(name || '');
  const vpnName   = rawName.replace(/[“”"]/g,'').replace(/[–—]/g,'-');
  const srv       = String(server || '').replace(/[“”"]/g,'');
  const isL2TP    = normalizeProto(proto) === 'l2tp';
  const cleanPSK  = (psk ?? '').toString().trim();
  const allUserArg = allUser ? ' -AllUserConnection' : '';

  const authArg = ' -AuthenticationMethod MSChapv2';
  const encArg  = ' -EncryptionLevel Required';

  const desired  = isL2TP ? 'L2tp' : 'Pptp';
  const tunnel   = isL2TP ? ' -TunnelType L2tp' : ' -TunnelType Pptp';
  const pskArg   = (isL2TP && cleanPSK) ? ` -L2tpPsk "${cleanPSK.replace(/"/g,'')}"` : '';

  const addCmd =
`Add-VpnConnection -Name "${vpnName}" -ServerAddress "${srv}"${tunnel}${pskArg}${allUserArg}${authArg}${encArg} -Force`;

  // Untuk L2TP SELALU recreate agar PSK terpasang
  return (`
$c = Get-VpnConnection -Name "${vpnName}" -ErrorAction SilentlyContinue
if (-not $c) {
  ${addCmd}
} else {
  if ('${desired}' -eq 'L2tp') {
    Remove-VpnConnection -Name "${vpnName}" -Force
    ${addCmd}
  } else {
    if ($c.TunnelType -ne '${desired}') {
      Remove-VpnConnection -Name "${vpnName}" -Force
      ${addCmd}
    } else {
      Set-VpnConnection -Name "${vpnName}" -ServerAddress "${srv}" -Force
    }
  }
}
  `).trim();
}

async function ensureProfile({ proto, server, name, psk, allUser }) {
  const cmd = buildAddVpnCommand({ proto, server, name, psk, allUser });
  sendLog('[VPN] PS cmd: ' + cmd.replace(/-L2tpPsk\s+"[^"]+"/i, '-L2tpPsk "***"'));
  await runPS(cmd); // biarkan throw kalau gagal
  sendLog('[VPN] profile prepared');
  if (normalizeProto(proto) === 'l2tp' && !(psk ?? '').toString().trim()) {
    sendLog('[VPN] L2TP tanpa PSK: Windows akan memakai IPsec sertifikat.');
  }
}

// ===== Actions =====
async function connectPPTP({ server, name, username, password }){
  try {
    await ensureProfile({ proto:'pptp', server, name });
  } catch (e) {
    const msg = e?.message || String(e);
    sendLog('[VPN] prepare failed: ' + msg);
    return { ok:false, error: msg };
  }

  await sleep(400); // beri waktu phonebook commit
  const out = await dialWithFallback(name, username, password);
  sendLog(out);
  return { ok:true, message:'VPN connected (PPTP)' };
}

async function connectL2TP({ server, name, username, password, psk }){
  try {
    await ensureProfile({ proto:'l2tp', server, name, psk });
  } catch (e) {
    const msg = e?.message || String(e);
    sendLog('[VPN] prepare failed: ' + msg);
    return { ok:false, error: msg };
  }

  await sleep(400); // beri waktu phonebook commit
  const out = await dialWithFallback(name, username, password);
  sendLog(out);
  return { ok:true, message:'VPN connected (L2TP)' };
}

async function connectVPN(cfg){
  const { proto, server } = cfg||{};
  if(!server) throw new Error('Server/Host wajib diisi');
  const name=(cfg?.name && String(cfg.name).trim()) || (server?`VPN-${server}`:'VPN');
  const pr=normalizeProto(proto);
  return pr==='l2tp'
    ? connectL2TP({ name, server, username:cfg?.username, password:cfg?.password, psk:cfg?.psk })
    : connectPPTP({ name, server, username:cfg?.username, password:cfg?.password });
}
async function disconnectVPN(){ const out=await runRAS('rasdial /disconnect'); sendLog(out); return { ok:true }; }

// ===== IPC =====
function registerWindowIpc(){
  ipcMain.on('vpn:open-window', ()=>openVpnWindow());
  ipcMain.on('vpn:close-window', ()=>{ if(vpnWin && !vpnWin.isDestroyed()) vpnWin.close(); });
  ipcMain.on('vpn:minimize-window', ()=>{ if(vpnWin && !vpnWin.isDestroyed()) vpnWin.minimize(); });
}
function registerStateIpc(){
  try{ ipcMain.removeHandler('vpn:get-ontop'); }catch{}
  try{ ipcMain.removeHandler('vpn:toggle-ontop'); }catch{}
  ipcMain.handle('vpn:get-ontop', async ()=>{
    try{
      const f=path.join(app.getPath('userData'),'vpn-window.json');
      if (fs.existsSync(f)) return !!JSON.parse(fs.readFileSync(f,'utf8')).alwaysOnTop;
    } catch {}
    return false;
  });
  ipcMain.handle('vpn:toggle-ontop', async ()=>{
    try{
      const f=path.join(app.getPath('userData'),'vpn-window.json');
      let cur=false; try{ if (fs.existsSync(f)) cur = !!JSON.parse(fs.readFileSync(f,'utf8')).alwaysOnTop; } catch {}
      const next = !cur;
      if (vpnWin && !vpnWin.isDestroyed()) vpnWin.setAlwaysOnTop(next);
      try{
        const s = fs.existsSync(f) ? JSON.parse(fs.readFileSync(f,'utf8')) : {};
        s.alwaysOnTop = next; fs.writeFileSync(f, JSON.stringify(s));
      } catch {}
      return next;
    } catch { return false; }
  });
}
function registerProfileIpc(){
  try{ ipcMain.removeHandler('vpn:load-list'); }catch{}
  ipcMain.handle('vpn:load-list', async ()=>{
    try{
      const { items, source } = await loadProfiles();
      return { ok:true, items, source, cached:(source==='Cache') };
    } catch(e){
      return { ok:false, error: e?.message || String(e) };
    }
  });
}
function registerConnectIpc(){
  try{ ipcMain.removeHandler('vpn:connect'); }catch{}
  try{ ipcMain.removeHandler('vpn:disconnect'); }catch{}
  ipcMain.handle('vpn:connect', async (_e, cfg)=>{
    try{ return await connectVPN(cfg||{}); }
    catch(e){ const err=e?.message||String(e); sendLog('[VPN] error: '+err); return { ok:false, error:err }; }
  });
  ipcMain.handle('vpn:disconnect', async ()=>{
    try{ return await disconnectVPN(); }
    catch(e){ const err=e?.message||String(e); sendLog('[VPN] error: '+err); return { ok:false, error:err }; }
  });
}

// ===== Init =====
function init(){ if(_initialized) return; _initialized = true; registerWindowIpc(); registerStateIpc(); registerProfileIpc(); registerConnectIpc(); sendLog('[VPN] IPC ready'); }

module.exports = { init, openVpnWindow };
