let globalData = [];
const searchInput = document.getElementById('searchInput');
const listContainer = document.getElementById('listContainer');

// ====== THEME ======
(function initTheme() {
  try {
    const saved = localStorage.getItem('theme');
    const isDark = saved === 'dark';
    document.body.classList.toggle('dark', isDark);
    const toggle = document.getElementById('darkToggle');
    if (toggle) toggle.checked = isDark;
  } catch {}
})();
document.getElementById('darkToggle')?.addEventListener('change', (e) => {
  const on = e.target.checked;
  document.body.classList.toggle('dark', on);
  try { localStorage.setItem('theme', on ? 'dark' : 'light'); } catch {}
});

// ====== LIST ======
function renderList(data) {
  const keyword = searchInput.value.toLowerCase();
  listContainer.innerHTML = '';
  const filtered = data.filter(item =>
    item.toko.toLowerCase().includes(keyword) ||
    item.nama.toLowerCase().includes(keyword) ||
    item.station.toLowerCase().includes(keyword)
  );

  for (const { toko, nama, station, ip } of filtered) {
    const div = document.createElement('div');
    div.className = 'list-item';

    const title = document.createElement('div');
    title.className = 'item-header';

    let color = '#333';
    if (station === 'RBWDCP') color = 'red';
    else if (station === 'STB') color = 'blue';
    else if (station === 'DVR') color = 'purple';
    else if (station === 'RBKONEKSI') color = 'orange';
    title.innerHTML = `▸ <b style="color:${color}">${toko}</b> – ${nama} – <b>${station}</b>`;

    const buttonsDiv = document.createElement('div');
    buttonsDiv.className = 'item-buttons';

    if (ip && ip.trim() !== '') {
      buttonsDiv.innerHTML += `<button class="btn-ping" onclick="window.electronAPI.ping('${ip}')">PING</button>`;
    }
    if (station === 'STB') {
      buttonsDiv.innerHTML += `<button class="btn-ftp" onclick="showFtpModal('${ip}', '/', '${toko}')">FTP</button>`;
    }
    if (station === 'RBWDCP' || station === 'RBKONEKSI') {
  buttonsDiv.innerHTML += `<button class="btn-mt" onclick="showMikrotikModal('${ip}','${station}','${toko}')">MikroTik</button>`;
}
    if (/^\d+$/.test(station)) {
      buttonsDiv.innerHTML += `<button class="btn-vnc" onclick="window.electronAPI.openVnc('${toko}', '${station}')">VNC</button>`;
    }
    if (station === 'DVR') {
      buttonsDiv.innerHTML += `<button class="btn-dvr" onclick="window.electronAPI.openDvr('${ip}')">DVR</button>`;
    }

    // background per station
    let bgColor = '#ffffff';
    if (station === 'RBWDCP') bgColor = '#ffe5e5';
    else if (station === 'STB') bgColor = '#e5f0ff';
    else if (station === 'DVR') bgColor = '#f3e5ff';
    else if (station === 'RBKONEKSI') bgColor = '#fff7e5';
    div.style.backgroundColor = bgColor;

    div.appendChild(title);
    div.appendChild(buttonsDiv);
    listContainer.appendChild(div);
  }
}

function setupSearchBox() {
  searchInput.value = '';
  searchInput.oninput = () => renderList(globalData);
}

window.electronAPI.getEntries().then(data => {
  globalData = data;
  renderList(globalData);
  setupSearchBox();
});

// ====== DELETE / ADD / UPDATE VNC ======
document.getElementById('openModalBtn').addEventListener('click', () => {
  document.getElementById('modalOverlay').style.display = 'flex';
  document.getElementById('inputToko').value = '';
  document.getElementById('inputNama').value = '';
  document.getElementById('inputStation').value = '';
  document.getElementById('inputIp').value = '';
});

document.getElementById('deleteModalBtn').addEventListener('click', async () => {
  const data = await window.electronAPI.getEntries();
  renderDeleteOptions(data);
  document.getElementById('deleteModal').style.display = 'flex';

  const si = document.getElementById('deleteSearchInput');
  si.value = '';
  si.addEventListener('input', () => {
    const keyword = si.value.toLowerCase();
    const filtered = data.filter(entry =>
      entry.toko.toLowerCase().includes(keyword) ||
      entry.nama.toLowerCase().includes(keyword) ||
      entry.station.toLowerCase().includes(keyword) ||
      entry.ip.toLowerCase().includes(keyword)
    );
    renderDeleteOptions(filtered);
  });
});

document.getElementById('updateVncBtn').addEventListener('click', async () => {
  const list = await window.electronAPI.getVncFiles();
  const select = document.getElementById('selectVncFile');
  select.innerHTML = '';
  list.forEach(file => {
    const opt = document.createElement('option');
    opt.value = file;
    opt.textContent = file;
    select.appendChild(opt);
  });
  document.getElementById('updateVncModal').style.display = 'flex';
});

function closeModal() { document.getElementById('modalOverlay').style.display = 'none'; }
function closeDeleteModal() { document.getElementById('deleteModal').style.display = 'none'; }
function closeUpdateVncModal() { document.getElementById('updateVncModal').style.display = 'none'; }

async function submitEntry() {
  const toko = document.getElementById('inputToko').value.trim();
  const nama = document.getElementById('inputNama').value.trim();
  const station = document.getElementById('inputStation').value.trim();
  const ip = document.getElementById('inputIp').value.trim();
  if (!toko || !nama || !station || !ip) return alert('⚠️ Semua kolom harus diisi!');

  await window.electronAPI.addEntry({ toko, nama, station, ip });
  const data = await window.electronAPI.getEntries();
  globalData = data;
  renderList(globalData);
  document.getElementById('inputToko').value = '';
  document.getElementById('inputNama').value = '';
  document.getElementById('inputStation').value = '';
  document.getElementById('inputIp').value = '';
  closeModal();
}

async function submitDelete() {
  const selectedIndex = document.getElementById('deleteSelect').value;
  if (selectedIndex === '') return alert('⚠️ Pilih entri yang akan dihapus.');
  if (!confirm('Yakin ingin menghapus entri ini?')) return;

  await window.electronAPI.deleteEntry(parseInt(selectedIndex));
  const newData = await window.electronAPI.getEntries();
  globalData = newData;
  renderList(globalData);
  renderDeleteOptions(newData);
  closeDeleteModal();
}

async function submitUpdateVnc() {
  const filename = document.getElementById('selectVncFile').value;
  const newPass = document.getElementById('inputVncPassword').value.trim();
  if (!filename || !newPass) return alert('⚠️ Pilih file dan isi password!');
  await window.electronAPI.updateVncPassword(filename, newPass);
  closeUpdateVncModal();
}

function renderDeleteOptions(entries) {
  const deleteSelect = document.getElementById('deleteSelect');
  deleteSelect.innerHTML = '<option value="">Pilih entri yang akan dihapus</option>';
  entries.forEach((entry, index) => {
    const option = document.createElement('option');
    option.value = entry.__index ?? index;
    option.textContent = `${entry.toko} – ${entry.nama} – ${entry.station} (${entry.ip})`;
    deleteSelect.appendChild(option);
  });
}

// ====== FTP ======
let currentFtpIP = null;
let currentFtpPath = '/';
let activeTransferId = null;
let currentFtpToko = '';

function newTransferId() {
  return 't' + Date.now() + Math.random().toString(16).slice(2);
}

function showProgress(on, label, pct) {
  const wrap = document.getElementById('ftpProgress');
  const lab  = document.getElementById('ftpProgressLabel');
  const bar  = document.getElementById('ftpProgressBar');
  const btns = document.getElementById('ftpProgressBtns');
  if (!wrap) return;
  wrap.style.display = on ? 'block' : 'none';
  if (lab && label) lab.textContent = label;
  if (typeof pct === 'number' && bar) bar.style.width = pct + '%';
  if (btns) btns.style.display = on ? 'flex' : 'none';
}

window.electronAPI.onFtpProgress?.((data) => {
  if (data.id !== activeTransferId) return;
  const label = `${data.dir === 'upload' ? 'Upload' : 'Download'} ${data.name}`;
  showProgress(true, label, data.percent ?? 0);
  if (data.percent >= 100) {
    activeTransferId = null;
    setTimeout(() => showProgress(false), 600);
    if (currentFtpIP) navigateFtp(currentFtpPath);
  }
});

function setBreadcrumbs() {
  const el = document.getElementById('ftpBreadcrumbs');
  if (!el) return;
  const parts = currentFtpPath.split('/').filter(Boolean);
  let acc = '/';
  const nodes = ['<a href="#" data-p="/">Root</a>'];
  parts.forEach(p => {
    acc = acc === '/' ? `/${p}` : `${acc}/${p}`;
    nodes.push('<span>/</span>', `<a href="#" data-p="${acc}">${p}</a>`);
  });
  el.innerHTML = nodes.join(' ');
  el.querySelectorAll('a[data-p]').forEach(a => {
    a.onclick = (e) => { e.preventDefault(); navigateFtp(a.getAttribute('data-p')); };
  });
}

function row(name, { icon='📄', right=[] , clickable=null } = {}) {
  const li = document.createElement('li');
  li.className = 'ftp-row';

  const left = document.createElement('div');
  left.className = 'ftp-name';
  const ic = document.createElement('span'); ic.textContent = icon;
  const title = document.createElement('span'); title.style.wordBreak = 'break-all'; title.innerHTML = name;
  left.appendChild(ic); left.appendChild(title);

  if (clickable) { left.style.cursor = 'pointer'; left.onclick = clickable; }

  const actions = document.createElement('div');
  actions.className = 'ftp-actions';
  right.forEach(btn => actions.appendChild(btn));

  li.appendChild(left);
  li.appendChild(actions);
  return li;
}

function makeBtn(text, cls, onclick) {
  const b = document.createElement('button');
  b.className = `btn-small ${cls}`;
  b.textContent = text;
  b.onclick = onclick;
  return b;
}

function renderFtpList(items) {
  const listEl = document.getElementById('ftpList');
  listEl.innerHTML = '';

  if (currentFtpPath !== '/') {
    listEl.appendChild(row('Ke atas', {
      icon: '⬆️',
      clickable: () => {
        const parent = currentFtpPath.split('/').slice(0, -1).join('/') || '/';
        navigateFtp(parent);
      }
    }));
  }

  if (!items || !items.length) {
    listEl.appendChild(row('(Kosong)', { icon: '•' }));
    return;
  }

  items.forEach(item => {
    const isDir = item.type === 2 || item.type === 'directory';
    const remotePath = currentFtpPath === '/' ? `/${item.name}` : `${currentFtpPath}/${item.name}`;

    if (isDir) {
      const del = makeBtn('Hapus', 'btn-delete', async (e) => {
        e.stopPropagation();
        if (!confirm(`Hapus folder "${item.name}" beserta isinya?`)) return;
        const res = await window.electronAPI.deleteFtp(currentFtpIP, remotePath, true);
        if (res?.status !== 'ok') alert('Gagal hapus folder.');
        await navigateFtp(currentFtpPath);
      });

      listEl.appendChild(row(
        `<a href="#" class="ftp-dir" data-p="${remotePath}">${item.name}</a>`,
        { icon: '📁', right: [del], clickable: () => navigateFtp(remotePath) }
      ));
    } else {
      const dl = makeBtn('Download', 'btn-download', async (e) => {
        e.stopPropagation();
        const id = newTransferId();
        activeTransferId = id;
        showProgress(true, `Download ${item.name}`, 0);
        const res = await window.electronAPI.downloadFtp(id, currentFtpIP, remotePath, true);
        if (res?.status === 'error') { alert('Gagal download: ' + res.message); showProgress(false); activeTransferId = null; }
      });
      const del = makeBtn('Hapus', 'btn-delete', async (e) => {
        e.stopPropagation();
        if (!confirm(`Hapus file "${item.name}"?`)) return;
        const res = await window.electronAPI.deleteFtp(currentFtpIP, remotePath, false);
        if (res?.status !== 'ok') alert('Gagal hapus file.');
        await navigateFtp(currentFtpPath);
      });

      listEl.appendChild(row(item.name, { icon: '📄', right: [dl, del] }));
    }
  });
}

async function navigateFtp(path) {
  const res = await window.electronAPI.listFtp(currentFtpIP, path);
  if (res?.error) return alert('Gagal membuka folder: ' + res.error);
  currentFtpPath = res.cwd || path;
  setBreadcrumbs();
  renderFtpList(res.items);
}

async function showFtpModal(ip, path = '/', toko) {
  if (typeof toko === 'string') currentFtpToko = toko;
  const titleEl = document.getElementById('ftpTitle');
  if (titleEl) titleEl.textContent = `FTP ${currentFtpToko || ''}`.trim();

  currentFtpIP = ip;
  document.getElementById('ftpModal').style.display = 'flex';
  showProgress(false);
  await navigateFtp(path);
}

function closeFtpModal() {
  document.getElementById('ftpModal').style.display = 'none';
  currentFtpIP = null;
  currentFtpPath = '/';
}

async function uploadToFtp() {
  if (!currentFtpIP) return;
  const id = newTransferId();
  activeTransferId = id;
  showProgress(true, 'Menyiapkan upload…', 0);
  const res = await window.electronAPI.uploadFtp(id, currentFtpIP, currentFtpPath, true);
  if (res?.status === 'error') { alert('Gagal upload: ' + res.message); showProgress(false); activeTransferId = null; }
}

async function downloadFromFtp(remotePath) {
  if (!currentFtpIP) return;
  const id = newTransferId();
  activeTransferId = id;
  showProgress(true, 'Menyiapkan download…', 0);
  const res = await window.electronAPI.downloadFtp(id, currentFtpIP, remotePath, true);
  if (res?.status === 'error') { alert('Gagal download: ' + res.message); showProgress(false); activeTransferId = null; }
}

async function deleteFromFtp(remotePath, isDir) {
  if (!currentFtpIP) return;
  if (!confirm(`Yakin hapus ${isDir ? 'folder' : 'file'} ini?`)) return;
  const res = await window.electronAPI.deleteFtp(currentFtpIP, remotePath, isDir);
  if (res?.status !== 'ok') alert('Gagal hapus.');
  await navigateFtp(currentFtpPath);
}

async function cancelActiveTransfer() {
  if (!activeTransferId) return;
  await window.electronAPI.cancelFtp(activeTransferId);
  activeTransferId = null;
  showProgress(false);
}
let mikrotikCtx = { ip: null, station: null, toko: null };

function showMikrotikModal(ip, station, toko) {
  mikrotikCtx = { ip, station, toko };
  const el = document.getElementById('mikrotikModal');
  const title = document.getElementById('mikrotikTitle');
  if (title) title.textContent = `Akses MikroTik ${toko || ip}`;
  // bind tombol
  const bWin = document.getElementById('btnWinbox');
  const bWeb = document.getElementById('btnWebfig');
  if (bWin) bWin.onclick = () => {
    window.electronAPI.openWinboxSmart(mikrotikCtx.ip, mikrotikCtx.station);
    closeMikrotikModal();
  };
  if (bWeb) bWeb.onclick = () => {
    window.electronAPI.openWebfig(mikrotikCtx.ip);
    closeMikrotikModal();
  };
  el.style.display = 'flex';
}
function closeMikrotikModal() {
  const el = document.getElementById('mikrotikModal');
  if (el) el.style.display = 'none';
  mikrotikCtx = { ip: null, station: null, toko: null };
}
