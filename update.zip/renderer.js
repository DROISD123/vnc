// ====================== renderer.js — FINAL (login + admin-only SQLyog) ======================

let globalData = [];

// ===== LICENSE GATE =====
async function ensureLicensedBeforeUse() {
  try {
    const res = await window.electronAPI.licenseCheck();
    if (res?.ok && res.activated) return true;

    // Tampilkan modal license dan blok UI lain
    const modal = document.getElementById('licenseModal');
    const input = document.getElementById('licenseKeyInput');
    const err   = document.getElementById('licenseErr');
    const btnAct= document.getElementById('btnLicenseActivate');
    const btnPs = document.getElementById('btnLicensePaste');

    function show(){ modal.style.display = 'flex'; input.focus(); }
    function hide(){ modal.style.display = 'none'; }

    const keyOkFmt = (k) => /^[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$/i.test(String(k||'').trim());

    btnPs?.addEventListener('click', async () => {
      try {
        const txt = await navigator.clipboard.readText();
        if (txt) { input.value = txt.trim().toUpperCase(); input.focus(); }
      } catch {}
    });

    async function doActivate(){
      err.textContent = '';
      const k = (input.value || '').trim().toUpperCase();
      if (!keyOkFmt(k)) { err.textContent = 'Format key salah.'; input.focus(); return; }
      const r = await window.electronAPI.licenseActivate(k);
      if (!r?.ok || !r.activated) { err.textContent = r?.error || 'Gagal aktivasi.'; return; }
      hide();
      return true;
    }

    btnAct && (btnAct.onclick = doActivate);
    input && input.addEventListener('keydown', (e)=>{ if(e.key==='Enter') doActivate(); });

    show();

    // Promise gate: tunggu sampai berhasil
    return await new Promise((resolve)=>{
      const iv = setInterval(async ()=>{
        const check = await window.electronAPI.licenseCheck();
        if (check?.ok && check.activated) { clearInterval(iv); resolve(true); }
      }, 400);
    });
  } catch {
    // fallback: kalau error IPC, jangan blokir (supaya tidak deadlock saat dev)
    return true;
  }
}

const searchInput = document.getElementById('searchInput');
const listContainer = document.getElementById('listContainer');

let loggedInUsername = '';
let loggedInUser = '';
let loggedInRole = 'user';

// ====== LOGIN (multi-user + role + log) ======
async function showLoginOnStart() {
  const scr    = document.getElementById('loginScreen');
  const userEl = document.getElementById('loginUser');
  const passEl = document.getElementById('loginPass');
  const btnEl  = document.getElementById('btnLogin');
  const errEl  = document.getElementById('loginError');

  if (!scr) return;
  scr.style.display = 'flex';

  function applyRoleUI(role) {
    loggedInRole = role || 'user';
    window.loggedInRole = loggedInRole;
    document.querySelectorAll('.admin-only').forEach(el => {
      el.style.display = (loggedInRole === 'admin') ? '' : 'none';
    });
  }

  async function tryLogin() {
    const u = (userEl.value || '').trim();
    const p = (passEl.value || '').trim();

    const res = await window.electronAPI.getAuth();
    const accounts = Array.isArray(res?.accounts) ? res.accounts : [];

    const found = accounts.find(a =>
      a.username && a.password &&
      a.username.toLowerCase() === u.toLowerCase() &&
      a.password === p
    );

    if (found) {
      scr.style.display = 'none';
      errEl.textContent = '';

      loggedInUsername = found.username;
      loggedInUser     = found.displayName || found.username;
      loggedInRole     = found.role || 'user';
      window.loggedInRole = loggedInRole;

      const slot = document.getElementById('currentUser');
      if (slot) slot.textContent = loggedInUser;

      applyRoleUI(loggedInRole);

      window.electronAPI.logActivity?.({ action: 'login', user: loggedInUser }).catch(()=>{});

      window.electronAPI.getEntries().then(data => {
        globalData = data || [];
        renderList(globalData);
      });
    } else {
      errEl.textContent = 'Username / password salah.';
      passEl.select();
    }
  }

  btnEl && (btnEl.onclick = tryLogin);
  passEl && passEl.addEventListener('keydown', (e) => { if (e.key === 'Enter') tryLogin(); });
  userEl && userEl.addEventListener('keydown', (e) => { if (e.key === 'Enter') tryLogin(); });
  userEl && userEl.focus();
}
(async function bootstrap(){
  const ok = await ensureLicensedBeforeUse();
  if (!ok) return; // safety
  showLoginOnStart();
})();


// ===== logoff =====
function logoff() {
  ['modalOverlay','deleteModal','updateVncModal','ftpModal','mikrotikModal','ftpChoiceModal','changePassModal']
    .forEach(id => { const el = document.getElementById(id); if (el) el.style.display = 'none'; });

  const slot = document.getElementById('currentUser');
  if (slot) slot.textContent = '';
  window.electronAPI.logActivity?.({ action: 'logoff', user: loggedInUser }).catch(()=>{});

  loggedInUsername = '';
  loggedInUser = '';
  loggedInRole = 'user';
  window.loggedInRole = 'user';

  const scr = document.getElementById('loginScreen');
  if (scr) scr.style.display = 'flex';
}
window.logoff = logoff;

// ===== Change Password =====
function openChangePass(){
  document.getElementById('changePassErr').textContent = '';
  document.getElementById('oldPass').value = '';
  document.getElementById('newPass').value = '';
  document.getElementById('newPass2').value = '';
  document.getElementById('changePassModal').style.display = 'flex';
}
function closeChangePass(){
  document.getElementById('changePassModal').style.display = 'none';
}

async function ensureGithubToken() {
  try {
    const token = prompt('Masukkan GitHub PAT:');
    if (!token) return { ok:false, error:'Token kosong' };
    const set = await window.electronAPI.setGithubToken(token);
    return set;
  } catch(e) {
    return { ok:false, error: e?.message || String(e) };
  }
}

async function submitChangePass(){
  const err = document.getElementById('changePassErr');
  const oldP = document.getElementById('oldPass').value.trim();
  const newP = document.getElementById('newPass').value.trim();
  const new2 = document.getElementById('newPass2').value.trim();
  err.textContent = '';

  if (!oldP || !newP || !new2) { err.textContent = 'Semua kolom wajib diisi.'; return; }
  if (newP.length < 4) { err.textContent = 'Password baru minimal 4 karakter.'; return; }
  if (newP !== new2)  { err.textContent = 'Ulangi password tidak cocok.'; return; }
  if (!loggedInUsername) { err.textContent = 'Tidak ada user login.'; return; }

  let gh;
  try {
    gh = await window.electronAPI.changePassword({
      username: loggedInUsername,
      oldPassword: oldP,
      newPassword: newP
    });
  } catch (e) {
    gh = { ok:false, error: e?.message || String(e) };
  }

  if (!gh?.ok && /token|unauthorized|401|403/i.test(gh?.error || '')) {
    const set = await ensureGithubToken();
    if (set?.ok) {
      try {
        gh = await window.electronAPI.changePassword({
          username: loggedInUsername,
          oldPassword: oldP,
          newPassword: newP
        });
      } catch (e2) {
        gh = { ok:false, error: e2?.message || String(e2) };
      }
    }
  }

  if (!gh?.ok) {
    const ses = await window.electronAPI.updatePasswordSession({
      username: loggedInUsername,
      oldPassword: oldP,
      newPassword: newP
    });
    if (!ses?.ok) { err.textContent = gh?.error || ses?.error || 'Gagal ganti password.'; return; }
    window.electronAPI.logActivity?.({ action: 'change_password', user: loggedInUser }).catch(()=>{});
    closeChangePass();
    alert('Password diubah untuk sesi ini (GitHub gagal, override sementara).');
    return;
  }

  window.electronAPI.logActivity?.({ action: 'change_password', user: loggedInUser }).catch(()=>{});
  closeChangePass();
  alert('Password berhasil diubah dan disimpan ke GitHub.');
}
window.openChangePass = openChangePass;
window.closeChangePass = closeChangePass;
window.submitChangePass = submitChangePass;

// ===== THEME =====
(function initTheme() {
  const saved = localStorage.getItem('theme');
  const isDark = saved === 'dark';
  document.body.classList.toggle('dark', isDark);
  const toggle = document.getElementById('darkToggle');
  if (toggle) toggle.checked = isDark;
})();
document.getElementById('darkToggle')?.addEventListener('change', (e) => {
  const on = e.target.checked;
  document.body.classList.toggle('dark', on);
  localStorage.setItem('theme', on ? 'dark' : 'light');
});

// ===== LIST =====
// GANTI renderList() kamu dengan versi ini
function renderList(data) {
  const list = document.getElementById('listContainer');
  if (!list) return;

  // ambil query pencarian
  const q = (searchInput?.value || '').trim().toLowerCase();

  // siapkan sumber data
  const src = Array.isArray(data) ? data : [];

  // filter berdasarkan toko/nama/station/ip
  const filtered = q
    ? src.filter(r => {
        const f1 = String(r.toko    || '').toLowerCase();
        const f2 = String(r.nama    || '').toLowerCase();
        const f3 = String(r.station || '').toLowerCase();
        const f4 = String(r.ip      || '').toLowerCase();
        return f1.includes(q) || f2.includes(q) || f3.includes(q) || f4.includes(q);
      })
    : src;

  // render hasil filter
  list.innerHTML = '';

  const isAdmin = String(window.loggedInRole || loggedInRole || 'user').toLowerCase() === 'admin';

  filtered.forEach((row) => {
    const toko    = row.toko    || '';
    const nama    = row.nama    || '';
    const station = row.station || '';
    const ip      = row.ip      || '';
    const stNorm  = String(station).trim();

    const item = document.createElement('div');
    item.className = 'list-item';

   const header = document.createElement('div');
header.className = 'item-header';
header.innerHTML = `
  <div class="item-title">
    <span class="toko-code">${toko}</span>
    <span class="sep"> – </span>
    <span class="toko-name">${nama}</span>
    <span class="station-inline"> ${station}</span>
    <span class="sep"> | </span>
    <span class="ip-inline">${ip}</span>
  </div>
`;
item.appendChild(header);


    const buttons = document.createElement('div');
    buttons.className = 'item-buttons';

    if (ip) {
      buttons.innerHTML += `<button class="btn-ping" onclick="window.electronAPI.ping('${ip}')">PING</button>`;
    }
    if (isAdmin && (stNorm === '01' || stNorm === '1')) {
      buttons.innerHTML += `<button class="btn-sqlyog" onclick="window.electronAPI.openSqlYog({ ip: '${ip}' })">SQLyog</button>`;
    }
    if (/^\d+$/.test(stNorm)) {
      buttons.innerHTML += `<button class="btn-vnc" onclick="window.electronAPI.openVnc('${toko}', '${station}')">VNC</button>`;
    }
    if (stNorm === 'RBWDCP' || stNorm === 'RBKONEKSI') {
      buttons.innerHTML += `<button class="btn-mt" onclick="showMikrotikModal('${ip}','${station}','${toko}')">MikroTik</button>`;
    }
    if (stNorm === 'DVR') {
      buttons.innerHTML += `<button class="btn-dvr" onclick="window.electronAPI.openDvr('${ip}', '${toko}')">DVR</button>`;
    }
    if (stNorm === 'STB') {
      buttons.innerHTML += `<button class="btn-ftp" onclick="showFtpChoiceModal('${ip}', '/', '${toko}')">FTP</button>`;
    }

    item.appendChild(buttons);
    list.appendChild(item);
  });
}

// GANTI setupSearchBox() kamu dengan ini (atau tambah listener di bawah)
function setupSearchBox() {
  if (!searchInput) return;
  searchInput.value = '';
  const rerender = () => renderList(globalData);
  searchInput.addEventListener('input', rerender);
  // bonus UX: ESC untuk clear
  searchInput.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') { searchInput.value = ''; rerender(); }
  });
}

// pastikan panggilan awal tetap seperti ini
window.electronAPI.getEntries().then(data => {
  globalData = data || [];
  renderList(globalData);
  setupSearchBox();
});


// ===== Semua fungsi FTP, modal, mikrotik, VNC dll tetap sama =====
// (tidak diubah, bisa langsung disalin dari versi kamu sebelumnya)

// ====== DELETE / ADD / UPDATE VNC ======
document.getElementById('openModalBtn')?.addEventListener('click', () => {
  document.getElementById('modalOverlay').style.display = 'flex';
  document.getElementById('inputToko').value = '';
  document.getElementById('inputNama').value = '';
  document.getElementById('inputStation').value = '';
  document.getElementById('inputIp').value = '';
});

document.getElementById('deleteModalBtn')?.addEventListener('click', async () => {
  const data = await window.electronAPI.getEntries();
  renderDeleteOptions(data);
  document.getElementById('deleteModal').style.display = 'flex';

  const si = document.getElementById('deleteSearchInput');
  si.value = '';
  si.addEventListener('input', () => {
    const keyword = si.value.toLowerCase();
    const filtered = data.filter(entry =>
      entry.toko.toLowerCase().includes(keyword) ||
      entry.nama.toLowerCase().includes(keyword) ||
      entry.station.toLowerCase().includes(keyword) ||
      entry.ip.toLowerCase().includes(keyword)
    );
    renderDeleteOptions(filtered);
  });
});

// (Single source of truth) — buka modal update VNC + dukung pencarian file
let vncFilesAll = [];
document.getElementById('updateVncBtn')?.addEventListener('click', async () => {
  const list = await window.electronAPI.getVncFiles();
  vncFilesAll = Array.isArray(list) ? list : [];
  const search = document.getElementById('searchVncFile');
  if (search) search.value = '';
  populateVncSelect(vncFilesAll, false);
  document.getElementById('updateVncModal').style.display = 'flex';
});

function closeModal() { document.getElementById('modalOverlay').style.display = 'none'; }
function closeDeleteModal() { document.getElementById('deleteModal').style.display = 'none'; }
function closeUpdateVncModal() { document.getElementById('updateVncModal').style.display = 'none'; }

async function submitEntry() {
  const toko = document.getElementById('inputToko').value.trim();
  const nama = document.getElementById('inputNama').value.trim();
  const station = document.getElementById('inputStation').value.trim();
  const ip = document.getElementById('inputIp').value.trim();
  if (!toko || !nama || !station || !ip) return alert('⚠️ Semua kolom harus diisi!');

  await window.electronAPI.addEntry({ toko, nama, station, ip });
  const data = await window.electronAPI.getEntries();
  globalData = data || [];
  renderList(globalData);
  document.getElementById('inputToko').value = '';
  document.getElementById('inputNama').value = '';
  document.getElementById('inputStation').value = '';
  document.getElementById('inputIp').value = '';
  closeModal();
}
window.submitEntry = submitEntry;

async function submitDelete() {
  const selectedIndex = document.getElementById('deleteSelect').value;
  if (selectedIndex === '') return alert('⚠️ Pilih entri yang akan dihapus.');
  if (!confirm('Yakin ingin menghapus entri ini?')) return;

  await window.electronAPI.deleteEntry(parseInt(selectedIndex, 10));
  const newData = await window.electronAPI.getEntries();
  globalData = newData || [];
  renderList(globalData);
  renderDeleteOptions(newData || []);
  closeDeleteModal();
}
window.submitDelete = submitDelete;

async function submitUpdateVnc() {
  const filename = document.getElementById('selectVncFile').value;
  const newPass = document.getElementById('inputVncPassword').value.trim();
  if (!filename || !newPass) return alert('⚠️ Pilih file dan isi password!');
  await window.electronAPI.updateVncPassword(filename, newPass);
  closeUpdateVncModal();
}
window.submitUpdateVnc = submitUpdateVnc;

function renderDeleteOptions(entries) {
  const deleteSelect = document.getElementById('deleteSelect');
  deleteSelect.innerHTML = '<option value="">Pilih entri yang akan dihapus</option>';
  (entries || []).forEach((entry, index) => {
    const option = document.createElement('option');
    option.value = entry.__index ?? index;
    option.textContent = `${entry.toko} – ${entry.nama} – ${entry.station} (${entry.ip})`;
    deleteSelect.appendChild(option);
  });
}

// ====== FTP ======
let currentFtpIP = null;
let currentFtpPath = '/';
let activeTransferId = null;
let currentFtpToko = '';

function newTransferId() {
  return 't' + Date.now() + Math.random().toString(16).slice(2);
}

function showProgress(on, label, pct) {
  const wrap = document.getElementById('ftpProgress');
  const lab  = document.getElementById('ftpProgressLabel');
  const bar  = document.getElementById('ftpProgressBar');
  const btns = document.getElementById('ftpProgressBtns');
  if (!wrap) return;
  wrap.style.display = on ? 'block' : 'none';
  if (lab && label) lab.textContent = label;
  if (typeof pct === 'number' && bar) bar.style.width = pct + '%';
  if (btns) btns.style.display = on ? 'flex' : 'none';
}

window.electronAPI.onFtpProgress?.((data) => {
  if (data.id !== activeTransferId) return;
  const label = `${data.dir === 'upload' ? 'Upload' : 'Download'} ${data.name}`;
  showProgress(true, label, data.percent ?? 0);
  if (data.percent >= 100) {
    activeTransferId = null;
    setTimeout(() => showProgress(false), 600);
    if (currentFtpIP) navigateFtp(currentFtpPath);
  }
});

function setBreadcrumbs() {
  const el = document.getElementById('ftpBreadcrumbs');
  if (!el) return;
  const parts = currentFtpPath.split('/').filter(Boolean);
  let acc = '/';
  const nodes = ['<a href="#" data-p="/">Root</a>'];
  parts.forEach(p => {
    acc = acc === '/' ? `/${p}` : `${acc}/${p}`;
    nodes.push('<span>/</span>', `<a href="#" data-p="${acc}">${p}</a>`);
  });
  el.innerHTML = nodes.join(' ');
  el.querySelectorAll('a[data-p]').forEach(a => {
    a.onclick = (e) => { e.preventDefault(); navigateFtp(a.getAttribute('data-p')); };
  });
}

function row(name, { icon='📄', right=[] , clickable=null } = {}) {
  const li = document.createElement('li');
  li.className = 'ftp-row';

  const left = document.createElement('div');
  left.className = 'ftp-name';
  const ic = document.createElement('span'); ic.textContent = icon;
  const title = document.createElement('span'); title.style.wordBreak = 'break-all'; title.innerHTML = name;
  left.appendChild(ic); left.appendChild(title);

  if (clickable) { left.style.cursor = 'pointer'; left.onclick = clickable; }

  const actions = document.createElement('div');
  actions.className = 'ftp-actions';
  right.forEach(btn => actions.appendChild(btn));

  li.appendChild(left);
  li.appendChild(actions);
  return li;
}

function makeBtn(text, cls, onclick) {
  const b = document.createElement('button');
  b.className = `btn-small ${cls}`;
  b.textContent = text;
  b.onclick = onclick;
  return b;
}

function renderFtpList(items) {
  const listEl = document.getElementById('ftpList');
  listEl.innerHTML = '';

  if (currentFtpPath !== '/') {
    listEl.appendChild(row('Ke atas', {
      icon: '⬆️',
      clickable: () => {
        const parent = currentFtpPath.split('/').slice(0, -1).join('/') || '/';
        navigateFtp(parent);
      }
    }));
  }

  if (!items || !items.length) {
    listEl.appendChild(row('(Kosong)', { icon: '•' }));
    return;
  }

  items.forEach(item => {
    const isDir = item.type === 2 || item.type === 'directory';
    const remotePath = currentFtpPath === '/' ? `/${item.name}` : `${currentFtpPath}/${item.name}`;

    if (isDir) {
      const del = makeBtn('Hapus', 'btn-delete', async (e) => {
        e.stopPropagation();
        if (!confirm(`Hapus folder "${item.name}" beserta isinya?`)) return;
        const res = await window.electronAPI.deleteFtp(currentFtpIP, remotePath, true);
        if (res?.status !== 'ok') alert('Gagal hapus folder.');
        await navigateFtp(currentFtpPath);
      });

      listEl.appendChild(row(
        `<a href="#" class="ftp-dir" data-p="${remotePath}">${item.name}</a>`,
        { icon: '📁', right: [del], clickable: () => navigateFtp(remotePath) }
      ));
    } else {
      const dl = makeBtn('Download', 'btn-download', async (e) => {
        e.stopPropagation();
        const id = newTransferId();
        activeTransferId = id;
        showProgress(true, `Download ${item.name}`, 0);
        const res = await window.electronAPI.downloadFtp(id, currentFtpIP, remotePath, true);
        if (res?.status === 'error') { alert('Gagal download: ' + res.message); showProgress(false); activeTransferId = null; }
      });
      const del = makeBtn('Hapus', 'btn-delete', async (e) => {
        e.stopPropagation();
        if (!confirm(`Hapus file "${item.name}"?`)) return;
        const res = await window.electronAPI.deleteFtp(currentFtpIP, remotePath, false);
        if (res?.status !== 'ok') alert('Gagal hapus file.');
        await navigateFtp(currentFtpPath);
      });

      listEl.appendChild(row(item.name, { icon: '📄', right: [dl, del] }));
    }
  });
}

async function navigateFtp(path) {
  const res = await window.electronAPI.listFtp(currentFtpIP, path);
  if (res?.error) return alert('Gagal membuka folder: ' + res.error);
  currentFtpPath = res.cwd || path;
  setBreadcrumbs();
  renderFtpList(res.items);
}

async function showFtpModal(ip, path = '/', toko) {
  if (typeof toko === 'string') currentFtpToko = toko;
  const titleEl = document.getElementById('ftpTitle');
  if (titleEl) titleEl.textContent = `FTP ${currentFtpToko || ''}`.trim();

  currentFtpIP = ip;
  document.getElementById('ftpModal').style.display = 'flex';
  showProgress(false);
  await navigateFtp(path);
}
window.showFtpModal = showFtpModal;

function closeFtpModal() {
  document.getElementById('ftpModal').style.display = 'none';
  currentFtpIP = null;
  currentFtpPath = '/';
}
window.closeFtpModal = closeFtpModal;

async function uploadToFtp() {
  if (!currentFtpIP) return;
  const id = newTransferId();
  activeTransferId = id;
  showProgress(true, 'Menyiapkan upload…', 0);
  const res = await window.electronAPI.uploadFtp(id, currentFtpIP, currentFtpPath, true);
  if (res?.status === 'error') { alert('Gagal upload: ' + res.message); showProgress(false); activeTransferId = null; }
}
window.uploadToFtp = uploadToFtp;

async function downloadFromFtp(remotePath) {
  if (!currentFtpIP) return;
  const id = newTransferId();
  activeTransferId = id;
  showProgress(true, 'Menyiapkan download…', 0);
  const res = await window.electronAPI.downloadFtp(id, currentFtpIP, remotePath, true);
  if (res?.status === 'error') { alert('Gagal download: ' + res.message); showProgress(false); activeTransferId = null; }
}
window.downloadFromFtp = downloadFromFtp;

async function deleteFromFtp(remotePath, isDir) {
  if (!currentFtpIP) return;
  if (!confirm(`Yakin hapus ${isDir ? 'folder' : 'file'} ini?`)) return;
  const res = await window.electronAPI.deleteFtp(currentFtpIP, remotePath, isDir);
  if (res?.status !== 'ok') alert('Gagal hapus.');
  await navigateFtp(currentFtpPath);
}
window.deleteFromFtp = deleteFromFtp;

async function cancelActiveTransfer() {
  if (!activeTransferId) return;
  await window.electronAPI.cancelFtp(activeTransferId);
  activeTransferId = null;
  showProgress(false);
}
window.cancelActiveTransfer = cancelActiveTransfer;

// ====== FTP CHOICE MODAL ======
let ftpChoiceCtx = { ip: null, path: '/', toko: '' };

function showFtpChoiceModal(ip, path = '/', toko = '') {
  ftpChoiceCtx = { ip, path, toko };
  const m = document.getElementById('ftpChoiceModal');
  m.style.display = 'flex';

  const btnInApp = document.getElementById('btnFtpInApp');
  const btnFz    = document.getElementById('btnFtpFileZilla');

  btnInApp.onclick = () => {
    m.style.display = 'none';
    showFtpModal(ftpChoiceCtx.ip, ftpChoiceCtx.path, ftpChoiceCtx.toko);
  };

  btnFz.onclick = async () => {
    m.style.display = 'none';
    try {
      const res = await window.electronAPI.openFileZilla({
        host: ftpChoiceCtx.ip,
        protocol: 'ftp'
      });
      if (!res?.ok) alert('Gagal membuka FileZilla: ' + (res?.error || 'unknown'));
    } catch (e) {
      alert('Gagal membuka FileZilla: ' + (e?.message || e));
    }
  };
}
function closeFtpChoiceModal() {
  const m = document.getElementById('ftpChoiceModal');
  if (m) m.style.display = 'none';
}
window.showFtpChoiceModal = showFtpChoiceModal;
window.closeFtpChoiceModal = closeFtpChoiceModal;

let mikrotikCtx = { ip: null, station: null, toko: null };

function showMikrotikModal(ip, station, toko) {
  mikrotikCtx = { ip, station, toko };
  const el = document.getElementById('mikrotikModal');
  const title = document.getElementById('mikrotikTitle');
  if (title) title.textContent = `Akses MikroTik ${toko || ip}`;
  const bWin = document.getElementById('btnWinbox');
  const bWeb = document.getElementById('btnWebfig');
  if (bWin) bWin.onclick = () => {
    window.electronAPI.openWinboxSmart(mikrotikCtx.ip, mikrotikCtx.station);
    closeMikrotikModal();
  };
  if (bWeb) bWeb.onclick = () => {
    window.electronAPI.openWebfig(mikrotikCtx.ip);
    closeMikrotikModal();
  };
  el.style.display = 'flex';
}
function closeMikrotikModal() {
  const el = document.getElementById('mikrotikModal');
  if (el) el.style.display = 'none';
  mikrotikCtx = { ip: null, station: null, toko: null };
}
window.showMikrotikModal = showMikrotikModal;
window.closeMikrotikModal = closeMikrotikModal;

document.getElementById('ftpChoiceModal')?.addEventListener('click', (e) => {
  if (e.target.id === 'ftpChoiceModal') closeFtpChoiceModal();
});

// ===== Update Password VNC: pencarian file =====
function populateVncSelect(files, keepSelected = true) {
  const select = document.getElementById('selectVncFile');
  const prev = select?.value;
  select.innerHTML = '';

  if (!files || !files.length) {
    const opt = document.createElement('option');
    opt.value = '';
    opt.textContent = 'Tidak ada file';
    opt.disabled = true;
    select.appendChild(opt);
    return;
  }

  files.forEach(f => {
    const opt = document.createElement('option');
    opt.value = f;
    opt.textContent = f;
    select.appendChild(opt);
  });

  if (keepSelected && prev && files.includes(prev)) {
    select.value = prev;
  }
}

// filter saat mengetik
document.getElementById('searchVncFile')?.addEventListener('input', () => {
  const q = document.getElementById('searchVncFile').value.trim().toLowerCase();
  const filtered = !q ? vncFilesAll : vncFilesAll.filter(f => f.toLowerCase().includes(q));
  populateVncSelect(filtered, false);
});

// bonus UX: Enter pada password langsung submit
document.getElementById('inputVncPassword')?.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') submitUpdateVnc();
});
(function(){
  function positionFab(){
    const footer = document.querySelector('.footer');
    const fab    = document.querySelector('.fab-container');
    if (!fab) return;
    const h = footer?.offsetHeight || 64;   // tinggi footer (fallback 64px)
    fab.style.bottom = (h + 16) + 'px';     // jarak 16px di atas footer
  }
  window.addEventListener('DOMContentLoaded', positionFab);
  window.addEventListener('resize', positionFab);
  const footerEl = document.querySelector('.footer');
  if (window.ResizeObserver && footerEl) {
    new ResizeObserver(positionFab).observe(footerEl);
  }
  setTimeout(positionFab, 300); // jaga-jaga layout terlambat
})();

// ===== Toggle FAB dari tombol footer "☰ Menu" =====
document.addEventListener('DOMContentLoaded', () => {
  const fabContainer = document.querySelector('.fab-container');
  const btnMenu = document.getElementById('btnMenu');
  if (btnMenu && fabContainer) {
    btnMenu.addEventListener('click', () => fabContainer.classList.toggle('active'));
  }
});

// ===== Modal Info User =====
function openUserInfoModal(data){
  const modal = document.getElementById('userInfoModal');
  if (!modal) return;
  modal.style.display = 'flex';

  const name = (data && data.name) || (document.getElementById('currentUser')?.textContent?.trim()) || 'User';
  const role = (data && data.role) || (function(){
    const anyAdmin = Array.from(document.querySelectorAll('.admin-only')).some(el => {
      const cs = window.getComputedStyle(el);
      return cs.display !== 'none' && cs.visibility !== 'hidden';
    });
    return anyAdmin ? 'Administrator' : 'Standard';
  })();
  const themeIsDark = document.body.classList.contains('dark');
  const theme = themeIsDark ? 'Dark' : 'Light';

  document.getElementById('userNameDisplay').textContent = name || 'User';
  document.getElementById('userRoleDisplay').textContent = role;
  document.getElementById('userTheme').textContent = theme;

  // App info via IPC (jika ada)
  if (window.electronAPI?.getAppInfo) {
    window.electronAPI.getAppInfo().then(info => {
      document.getElementById('appVersion').textContent = info?.version || '-';
      document.getElementById('appPlatform').textContent = info?.os || '-';
    }).catch(()=>{
      document.getElementById('appVersion').textContent = '-';
      document.getElementById('appPlatform').textContent = '-';
    });
  } else {
    document.getElementById('appVersion').textContent = '-';
    document.getElementById('appPlatform').textContent = '-';
  }

  // Terapkan foto (sementara kosong)
  applyUserPhoto(name);
}
function closeUserInfo(){ document.getElementById('userInfoModal').style.display = 'none'; }
function showUserInfo(){ openUserInfoModal(); }

// ===== Foto User (sementara: kosong) =====
function applyUserPhoto(name){
  // Foto sengaja dikosongkan
  const img = document.getElementById('userPhotoImg');
  const ph  = document.getElementById('userPhotoPh');
  if (img){ img.removeAttribute('src'); img.style.display = 'none'; }
  if (ph){ ph.textContent = ''; ph.style.display = 'grid'; }
}
// (input & tombol ganti foto sudah ada, tapi tidak diaktifkan dulu)

// ===== Posisi FAB selalu di atas footer =====
(function(){
  function positionFab(){
    const footer = document.querySelector('.footer');
    const fab    = document.querySelector('.fab-container');
    if (!fab) return;
    const h = footer?.offsetHeight || 64;
    fab.style.bottom = (h + 16) + 'px';
  }
  window.addEventListener('DOMContentLoaded', positionFab);
  window.addEventListener('resize', positionFab);
  const footerEl = document.querySelector('.footer');
  if (window.ResizeObserver && footerEl) new ResizeObserver(positionFab).observe(footerEl);
  setTimeout(positionFab, 300);
})();

const appVer = appInfo?.version || '-';
const locVer = local?.version ? ` (local ${local.version})` : '';
document.getElementById('aboutVersion').textContent = `Version ${appVer}${locVer}`;
// setelah homepageBtn/docsBtn/eulaBtn:
const copyBtn = document.getElementById('btnCopyInfo');
if (copyBtn) copyBtn.onclick = async () => {
  const dev = document.getElementById('aboutDeveloper')?.textContent || '';
  const ver = document.getElementById('aboutVersion')?.textContent || '';
  const bld = document.getElementById('aboutBuild')?.textContent || '';
  const os  = document.getElementById('aboutOS')?.textContent || '';
  const txt = `VNC Launcher\n${dev}\n${ver}\n${bld}\n${os}`;
  try { await navigator.clipboard.writeText(txt); alert('Detail disalin'); }
  catch { alert('Gagal menyalin'); }
};
